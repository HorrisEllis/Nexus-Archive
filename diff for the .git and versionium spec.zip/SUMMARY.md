# SnapshotGate → Versionium merge — 2026-09-01

Reverses the 2026-09-01 reconciliation's decision to un-conflate idearium's
SnapshotGate/SnapshotRestoreGate from Versionium. idearium now has **no
local snapshot copy** — cortex/versionium is the only place commit/restore
state lives.

## Apply

Either `patch -p1 < *.diff` from repo root for each file, or copy the six
files under `patched/` directly over their real paths. Both are the same
content.

## Files touched

| File | What changed |
|---|---|
| `cortex/versionium/index.js` | `commit()` gained an optional `state` param (deep-cloned, stored on the commit row). New `getState(commitId)` — direct-restore read, distinct from the existing `restore()`'s causal-replay context, which is untouched. |
| `cortex/boot.js` | `POST /api/versionium/commit` forwards `state`. New `GET /api/versionium/state/:commitId`. |
| `idearium/index.js` | `SnapshotGate`/`SnapshotRestoreGate` and their SISO registrations removed. Local `idearium_snapshots` table dropped from `TABLES`/`freshDB()`. `snapshots()`/`snapshot()`/`diffSnapshots()` are now async, reading cortex/versionium's history/state over HTTP (`lib/nexus-client.js`). New `commitSnapshot()`/`restoreSnapshot()` (auto-stash before overwrite, same as before). |
| `idearium/cli/index.js` | `push`/`log` commands await the new async methods; failures now surface as real errors instead of undefined reads. |
| `idearium/api/index.js` | All five `/api/snapshots/*` handlers repointed to the new async methods. `restore`'s response shape preserved (`ideas`/`specs`/`gaps` counts) for backward compat, `stashCommitId` added. |
| `tests/modules/test-versionium-migration.js` | Added V-008/009/010 covering `state`/`getState()`. |

## Why not async SISO gates

Checked `siso/core/index.js` directly: `Stream.emit()` calls
`gate.transform()` with no `await` and no promise handling. An async
`transform()` would have its returned promise silently dropped — the CLI's
old `os.emit(...); os.snapshots()[0]` pattern would read stale state before
the network call resolved. Nothing outside `idearium/index.js` listens for
`idearium.snapshot.committed`/`.restored` on the bus (checked, zero hits),
so commit/restore were pulled out of the SISO pipeline entirely and are now
direct async methods CLI/API await. This means they're no longer SISO
events — a real behavior change, not just an implementation detail.

## Verified, not just reviewed

Ran the actual test suite against the patched module (Node v22, real
`jaaDB`/kernel/rfr2 deps, isolated `JAA_DATA_DIR`):

```
✓ V-001 commit() accepts and stores a system field
✓ V-002 commit() without system stores null, not undefined/crash
✓ V-003 branch head correctly scoped per branch (no cross-branch parentId bug)
✓ V-004 restore() on a real commit returns a real completion record
✓ V-005 restore() on a nonexistent commit reports a real error, not a crash
✓ V-006 calendar() returns entries for a MANUAL commit
✓ V-007 setDeps(fieldReader) wires without throwing
✓ V-008 commit() with a state payload stores it, getState() returns it back deep-cloned
✓ V-009 getState() on a commit made without state reports a real error
✓ V-010 getState() on a nonexistent commit reports a real error

10 passed, 0 failed
```

All five touched files also pass `node --check` individually. The idearium
side (index.js/cli/api) couldn't be exercised end-to-end here — it needs
the running guardian/cortex/idearium process trio, not just a module
require — so that's real, remaining risk, not confirmed by this pass.

## Known gaps — not silently solved

- **`snrDelta`** (branch-relative, vs. the prior same-branch commit) is not
  reconstructed. The old gate computed it from a local array scan that no
  longer exists. Left at `0` with a comment. Real follow-up: derive it from
  two adjacent same-branch commits' `state.snr` via the history list.
- **Pre-merge `idearium_snapshots` rows are orphaned.** Not deleted, not
  auto-migrated into `versionium_commits`. Real, separate decision:
  write a one-time backfill script, or accept the history gap.
- **New availability dependency.** idearium's commit/restore now require
  cortex to be up and reachable over HTTP. Before this merge, idearium's
  own snapshots worked fully offline/in-process. Worth deciding whether
  that tradeoff is acceptable or needs a local fallback queue (similar to
  `lib/nexus-client.js`'s existing `postDurable`/buffer-drain pattern,
  which this patch did NOT use — it calls `nx.post`/`nx.get` directly).
- **idearium's `registry-components.js` snapshot descriptions** weren't
  changed — checked, they're generic enough to stay accurate — but nobody
  updated `docs/versionium.spec`'s own history/gaps sections to record
  *this* reversal. That spec still says (as of 2026-09-01) that idearium
  "keeps its own separate feature" — now false. Worth a follow-up spec
  update so the next reader isn't working from a stale account, the same
  class of problem this whole migration exists to fix.
