'use strict';
// ── core/raid/index.js — RAID v6 ─────────────────────────────────────────────
// UUID: mod-raid-v6-0000-4000-0000-000000000001
//
// RAID — Routing and Agent Intelligence Dispatcher v6
// The orchestrator's ONLY control layer for agent dispatch.
//
// AXIOMS (enforced in code):
//   LAW_I  LOCAL_FIRST — Ollama first. Always. Bypassed only if 3+ consecutive fails.
//   LAW_II MEMORY_AUTHORITY — every decision written to JAA BEFORE dispatch.
//   §1.1   DETERMINISTIC — f(call, healthSnapshot, weights) → same decision always.
//   §1.2   NOTHING_SILENT — every routing failure logged + gap emitted.
//
// LEARNING: updates (intentCluster × agent) weight table from outcomes.
// SYSTEM-AWARE: probes all agents every 10s. Never dispatches to a dead system.
// BRAIN: uses Ollama to analyze failures every 60s and adjust weights.

const path = require('path');
const http = require('http');
const fs   = require('fs');
const { jaaDB, uid } = require('../../memory/jaa-db');
const nexusConfig = require('../../../lib/nexus-config');

let ESSKernel = null;
try { ESSKernel = require('../../lib/ess').ESSKernel; } catch(_) {}

const MODULE_ID = 'raid';
const VERSION   = '6.2.0';

// ── Config (orchestrator.config.json → raid block; live, hot-reloaded) ──────
function _raidCfg() {
  const cfg = nexusConfig.get();
  return {
    healthPollMs: cfg.raid?.healthPollMs ?? HEALTH_INTERVAL_DEFAULT,
    tickMs: cfg.raid?.tickMs ?? 3000,
    localFirst: cfg.raid?.localFirst !== false,
    localFirstFailThreshold: cfg.raid?.localFirstFailThreshold ?? 3,
    agents: cfg.raid?.agents || null, // null = all agents enabled (back-compat)
  };
}
function _agentEnabled(agent) {
  const agents = _raidCfg().agents;
  if (!agents) return true;
  return agents[agent]?.enabled !== false;
}

// ── ESS (optional) ────────────────────────────────────────────────────────────
let _ess = null;
if (ESSKernel) {
  const ld = path.join(__dirname, '../../../data/cortex/ledger');
  try { fs.mkdirSync(ld, { recursive: true }); } catch(_) {}
  _ess = new ESSKernel({
    bindingLogPath: path.join(ld, 'ess-bindings.ndjson'),
    hashStorePath:  path.join(ld, 'ess-hashes.json'),
  });
  _ess.on('ess:unresolve', evt => {
    try {
      jaaDB.insert('gaps', { uuid: uid(), type: 'raid_ess_unresolve', path: 'raid/ess',
        body: `ESS UNRESOLVE: role "${evt.role}" — ${evt.reason}`,
        severity: 'medium', status: 'open', source: MODULE_ID,
        causedBy: null, createdAt: Date.now(), attempts: 0, ts: Date.now() });
    } catch(_) {}
  });
}

// ── Health cache ──────────────────────────────────────────────────────────────
const HEALTH_INTERVAL_DEFAULT = 10000;
const HEALTH_TIMEOUT  = 2000;

const _health = {
  ollama:             { online: false, lastCheck: 0, consecutiveFails: 0, latencyMs: 0, models: [] },
  'guardian-claude':  { online: false, lastCheck: 0, consecutiveFails: 0, latencyMs: 0 },
  'guardian-chatgpt': { online: false, lastCheck: 0, consecutiveFails: 0, latencyMs: 0 },
  claude:             { online: true,  lastCheck: 0, consecutiveFails: 0, latencyMs: 0 },
  chatgpt:            { online: true,  lastCheck: 0, consecutiveFails: 0, latencyMs: 0 },
  gemini:             { online: true,  lastCheck: 0, consecutiveFails: 0, latencyMs: 0 },
  perplexity:         { online: true,  lastCheck: 0, consecutiveFails: 0, latencyMs: 0 },
};

async function _probeAgent(agent) {
  const probes = {
    ollama:             { host: '127.0.0.1', port: 11434, path: '/api/tags' },
    'guardian-claude':  { host: '127.0.0.1', port: 7820,  path: '/providers' },
    'guardian-chatgpt': { host: '127.0.0.1', port: 7820,  path: '/providers' },
  };
  const probe = probes[agent];
  if (!probe) return; // claude/chatgpt assumed available unless proven otherwise

  const t0 = Date.now();
  return new Promise(resolve => {
    const req = http.get({ ...probe, timeout: HEALTH_TIMEOUT }, res => {
      const latMs = Date.now() - t0;
      let body = '';
      res.on('data', d => body += d);
      res.on('end', () => {
        const ok = res.statusCode === 200;
        if (agent === 'ollama' && ok) {
          try {
            const d = JSON.parse(body);
            const models = (d.models || []).map(m => m.name || m.model || '').filter(Boolean);
            _health.ollama.online    = models.length > 0;
            _health.ollama.models    = models;
            _health.ollama.latencyMs = latMs;
          } catch { _health.ollama.online = ok; }
        } else if (agent === 'guardian-claude' || agent === 'guardian-chatgpt') {
          try {
            const d     = JSON.parse(body);
            const prov  = agent === 'guardian-claude' ? 'claude' : 'chatgpt';
            const provs = d.providers || d.connected || {};
            _health[agent].online    = !!provs[prov] || Object.keys(provs).some(k => k.startsWith(prov));
            _health[agent].latencyMs = latMs;
          } catch { _health[agent].online = false; }
        }
        if (!ok) _health[agent].consecutiveFails++;
        else     _health[agent].consecutiveFails = 0;
        _health[agent].lastCheck = Date.now();
        resolve();
      });
    });
    req.on('error',   () => { _health[agent].online = false; _health[agent].consecutiveFails++; _health[agent].lastCheck = Date.now(); resolve(); });
    req.on('timeout', () => { req.destroy(); _health[agent].online = false; resolve(); });
  });
}

async function _refreshHealth() {
  await Promise.all(['ollama','guardian-claude','guardian-chatgpt'].map(_probeAgent));
  try {
    jaaDB.insert('event_log', { uuid: uid(), type: 'raid.health',
      payload: JSON.stringify(Object.fromEntries(
        Object.entries(_health).map(([k,v]) => [k, { online: v.online, fails: v.consecutiveFails }])
      )), source: MODULE_ID, ts: Date.now() });
  } catch(_) {}
}

// ── Weight table (learning) ───────────────────────────────────────────────────
const _weights = new Map();
const _WEIGHTS_FILE = path.join(__dirname, '../../../data/cortex/ledger/raid-weights.json');

function _wKey(cluster, agent) { return `${cluster}:${agent}`; }

function _getW(cluster, agent) {
  return _weights.get(_wKey(cluster, agent)) || {
    successCount: 0, failCount: 0, totalMs: 0,
    successRate: 0.5, avgMs: 0, callCount: 0, lastUsed: 0,
  };
}

function _updateW(cluster, agent, ok, ms) {
  const w = _getW(cluster, agent);
  if (ok) w.successCount++; else w.failCount++;
  w.totalMs    += ms;
  w.callCount++;
  w.successRate = w.successCount / w.callCount;
  w.avgMs       = Math.round(w.totalMs / w.callCount);
  w.lastUsed    = Date.now();
  _weights.set(_wKey(cluster, agent), w);
  try { fs.mkdirSync(path.dirname(_WEIGHTS_FILE), { recursive: true }); fs.writeFileSync(_WEIGHTS_FILE, JSON.stringify(Object.fromEntries(_weights), null, 2)); } catch(_) {}
}

function _loadWeights() {
  try { const raw = JSON.parse(fs.readFileSync(_WEIGHTS_FILE, 'utf8')); for (const [k,v] of Object.entries(raw)) _weights.set(k,v); } catch(_) {}
}

// ── Intent clustering (deterministic, no randomness) ─────────────────────────
const CLUSTERS = {
  // Local-first work
  code:       /\b(code|function|class|module|implement|build|write|create|fix|refactor|typescript|javascript|python|rust|node|patch)\b/i,
  spec:       /\b(spec|design|architecture|system|plan|structure|schema|contract|api|blueprint)\b/i,
  data:       /\b(data|json|csv|sql|database|query|table|migrate|transform|parse)\b/i,
  diagnostic: /\b(error|fail|broken|debug|trace|diagnose|crash|exception|issue|bug|stack)\b/i,
  analysis:   /\b(analyze|analyse|explain|understand|review|audit|check|evaluate|compare|summarize)\b/i,

  // Vision/UI — Gemini primary
  vision:     /\b(image|screenshot|photo|visual|ui|interface|design|layout|render|pixel|svg|canvas|color|theme|mock)\b/i,

  // Research/facts — Perplexity primary
  research:   /\b(research|fact|current|today|news|latest|real.world|source|citation|search|web|grounded|up.to.date)\b/i,

  // Hostile/adversarial — ChatGPT primary
  hostile:    /\b(attack|adversar|hostile|red.team|pentest|bypass|exploit|break|challenge|counter|stress.test|find.flaw|worst.case)\b/i,

  // Forge/SEAM — highest stakes, Claude reserve
  forge:      /\b(forge|seam|patch|repair|self.heal|autonomous|critical.fix|production)\b/i,
};

function _cluster(text) {
  if (!text) return 'general';
  for (const [name, re] of Object.entries(CLUSTERS)) if (re.test(text)) return name;
  return 'general';
}

// ── Deterministic routing decision ───────────────────────────────────────────
// PURE FUNCTION: same (call, healthSnap, weights) → same decision. Always.
//
// PROVIDER HIERARCHY (by intent cluster):
//   Local/private:  ollama → chatgpt → claude
//   Vision/UI:      gemini → claude
//   Research/facts: perplexity → claude
//   Hostile/attack: chatgpt → claude
//   Forge/critical: ollama → claude (never chatgpt — output quality matters)
//
// LAW_I: Ollama always first for code/spec/data/diagnostic/analysis/general.
// LAW_III: Claude always last (reserve, highest quality, most expensive).

// Per-cluster fallback chains
const CLUSTER_CHAINS = {
  code:       ['ollama', 'chatgpt', 'claude'],
  spec:       ['ollama', 'claude'],
  data:       ['ollama', 'chatgpt', 'claude'],
  diagnostic: ['ollama', 'chatgpt', 'claude'],
  analysis:   ['ollama', 'chatgpt', 'claude'],
  vision:     ['gemini', 'claude'],
  research:   ['perplexity', 'chatgpt', 'claude'],
  hostile:    ['chatgpt', 'claude'],
  forge:      ['ollama', 'claude'],      // deepseek-coder → qwen2.5-coder → mistral (via OLLAMA_SEAM_MODELS), then claude reserve
  general:    ['ollama', 'chatgpt', 'claude'],
};

// ALL providers are NCP — browser tab + userscript. No API keys. No REST calls.
// §AXIOM: No APIs, ever.
// Add a provider by installing its userscript in the browser. That's it.
const NCP_PROVIDERS = new Set([
  'ollama',           // local — no browser tab needed
  'guardian-claude',  // claude.ai tab + userscript-claude.js
  'guardian-chatgpt', // chatgpt.com tab + userscript-chatgpt.js
  'gemini',           // gemini.google.com tab + userscript-gemini.js
  'perplexity',       // perplexity.ai tab + userscript-perplexity.js
]);

function _agentAvailable(agent, healthSnap) {
  if (!_agentEnabled(agent)) return false; // §toggle: orchestrator.config.json → raid.agents.<name>.enabled
  if (agent === 'ollama') return !!healthSnap['ollama']?.online;
  // All other providers: NCP browser tab — check if tab is connected
  const ncpKey = agent.startsWith('guardian-') ? agent : 'guardian-' + agent;
  return !!(healthSnap[agent]?.online || healthSnap[ncpKey]?.online);
}

function _decide(call, healthSnap, weights) {
  const intent    = call.intent || call.prompt || '';
  const cluster   = _cluster(intent);
  const preferred = (call.preferredAgent || '').toLowerCase();

  // Rule 1: explicit preference + available
  if (preferred && preferred !== 'auto' && _agentAvailable(preferred, healthSnap)) {
    return { agent: preferred, reason: `explicit:${preferred}`, cluster };
  }

  // Rule 2: intent-specific cluster chain
  const chain = CLUSTER_CHAINS[cluster] || CLUSTER_CHAINS.general;

  for (const agent of chain) {
    if (!_agentAvailable(agent, healthSnap)) continue;

    // For ollama: respect LAW_I failure tracking
    if (agent === 'ollama') {
      const oh = healthSnap['ollama'];
      if (oh.consecutiveFails >= 3) continue; // bypass to next in chain
      const w = weights.get(_wKey(cluster, 'ollama'));
      if (w && w.callCount >= 3 && w.successRate < 0.3) continue; // too many failures
    }

    const w = weights.get(_wKey(cluster, agent));
    const successRate = w?.successRate ?? 0.5;
    const callCount   = w?.callCount   ?? 0;

    // Skip agents with very poor track record (but not Claude — it's the reserve)
    if (agent !== 'claude' && callCount >= 5 && successRate < 0.2) continue;

    return { agent, reason: 'cluster_chain:' + cluster, cluster };
  }

  // Absolute fallback: claude (always reserve)
  return { agent: 'claude', reason: 'LAW_I:claude_reserve', cluster };
}

// ── Ollama brain (analyzes failures, adjusts weights) ────────────────────────
const _failures = [];
let _cfg = {};

async function _brainTick() {
  if (!_health['ollama']?.online || _failures.length === 0) return;
  const batch = _failures.splice(0, 5);
  const model = _cfg.ollamaModel || _health.ollama.models?.[0] || 'mistral';

  const prompt =
    'You are the NEXUS RAID routing analyzer. Here are routing failures.\n' +
    'Respond ONLY with JSON: {"analysis":"...","suggestions":[{"cluster":"...","agent":"..."}]}\n' +
    'Agents: ollama,guardian-claude,guardian-chatgpt,claude,chatgpt\n' +
    'LAW_I: ollama must be first unless health fails 3 times.\n\n' +
    'Failures:\n' + JSON.stringify(batch);

  try {
    const resp = await new Promise((res, rej) => {
      const b   = JSON.stringify({ model, prompt, stream: false });
      const req = http.request({
        hostname:'127.0.0.1', port:11434, path:'/api/generate',
        method:'POST', headers:{'Content-Type':'application/json'}, timeout:20000,
      }, r => { let d=''; r.on('data',c=>d+=c); r.on('end',()=>res(JSON.parse(d))); });
      req.on('error',rej); req.on('timeout',()=>req.destroy()); req.write(b); req.end();
    });
    const analysis = JSON.parse((resp.response||'').replace(/```json|```/g,'').trim());
    if (analysis?.suggestions) {
      for (const s of analysis.suggestions) {
        if (!s.cluster || !s.agent) continue;
        const w = _getW(s.cluster, s.agent);
        if (w.callCount < 5) { w.successCount = Math.max(w.successCount,1); w.callCount=Math.max(w.callCount,2); w.successRate=w.successCount/w.callCount; _weights.set(_wKey(s.cluster,s.agent),w); }
      }
      try { fs.writeFileSync(_WEIGHTS_FILE, JSON.stringify(Object.fromEntries(_weights), null, 2)); } catch(_) {}
      console.log(`[raid] brain: ${(analysis.analysis||'').slice(0,80)}`);
    }
  } catch(_) {}
}

// ── Main dispatch ─────────────────────────────────────────────────────────────

async function _dispatch(call, decision) {
  const t0 = Date.now();

  // ── Intelligence Bridge — query before routing ───────────────────────────
  let _evidence = { weight: 0, recommendation: null };
  try {
    const ib = require('./intelligence-bridge');
    _evidence = ib.queryBefore({
      cluster:    decision.cluster,
      faultClass: call.faultClass || null,
      intent:     call.intent || call.prompt || '',
      jobId:      call.uuid,
    });
    // If intelligence strongly recommends a provider and confidence is high,
    // nudge the decision (never override — advisory only)
    if (_evidence.recommendation && _evidence.weight > 0.6) {
      call._intelligenceRecommendation = _evidence.recommendation;
      call._intelligenceWeight         = _evidence.weight;
    }
  } catch(e) {
    console.warn('[raid/intelligence] query failed:', e.message);
  }

  // ── SNR Filter — invariants first, patterns second, AI last ──────────────
  // Tokens ∝ unresolved meaning. Only genuine unknowns reach AI.
  try {
    const snr = require('./snr-filter');
    const filterResult = snr.filter({
      intent:     call.intent || call.prompt || '',
      cluster:    decision.cluster,
      faultClass: call.faultClass || null,
      jobId:      call.uuid,
    });

    if (!filterResult.dispatch) {
      // Resolved locally — zero tokens
      const ms = Date.now() - t0;
      // Feed outcome back to intelligence layer
      try {
        const ib = require('./intelligence-bridge');
        ib.feedOutcome(call, decision, { ok:true, provider:'local', durationMs:ms });
      } catch(_) {}
      jaaDB.insert('event_log', {
        uuid: uid(), type: 'raid.resolved_locally',
        payload: { cluster: decision.cluster, type: filterResult.type,
                   reason: filterResult.reason, snr: filterResult.snr, ms },
        source: 'raid-snr-filter', causedBy: call.uuid, ts: Date.now(),
      });
      console.log(`[raid/snr] resolved locally: ${filterResult.reason}`);
      return { ok: true, agent: 'local', result: filterResult.result,
               tokens: 0, snr: filterResult.snr, ms };
    }

    // If open loop flagged — inject context into call
    if (filterResult.type === 'open_loop' && filterResult.injectContext) {
      call._snrContext = filterResult.flag;
    }
  } catch(e) {
    console.warn('[raid/snr] filter failed (continuing to dispatch):', e.message);
  }

  // ESS path
  if (_ess?.hasRole(decision.agent)) {
    const r = await _ess.callto(decision.agent, call);
    if (r.resolved) {
      jaaDB.update('agent_calls', call.uuid, { status:'complete', response:JSON.stringify(r.output), completedAt:Date.now(), routeMethod:'ess' });
      _updateW(decision.cluster, decision.agent, true, Date.now()-t0);
      return r.output;
    }
  }

  // Guardian path — local agent (ollama, no browser tab) or browser-tab agent
  // (claude/chatgpt). All three go through Guardian's HTTP /command, not a
  // direct require() — RAID and Guardian are separate processes; reaching
  // into another process's module tree by path is not a real call, it's a
  // second copy of the module running disconnected from the one that's
  // actually wired to ollama-runtime.js's hardened client. Guardian owns
  // every local-model touchpoint; RAID asks it, the same way it already
  // asks for claude/chatgpt tab dispatch below.
  if (decision.agent === 'ollama' || decision.agent === 'guardian-claude' || decision.agent === 'guardian-chatgpt') {
    const prov = decision.agent === 'guardian-claude'  ? 'claude'
               : decision.agent === 'guardian-chatgpt' ? 'chatgpt'
               : 'ollama';
    await new Promise((res,rej)=>{
      const b=JSON.stringify({ provider:prov, command:call.command||'code', prompt:call.prompt, jobId:call.uuid });
      const req=http.request({ hostname:'127.0.0.1',port:7820,path:'/command',method:'POST',headers:{'Content-Type':'application/json'},timeout:5000 },r=>{ r.resume(); res(); });
      req.on('error',rej); req.write(b); req.end();
    });
    jaaDB.update('agent_calls', call.uuid, { status:'delivered', deliveredAt:Date.now() });
    _updateW(decision.cluster, decision.agent, true, Date.now()-t0);
    return;
  }

  // Direct agent module
  try {
    const mod = require(`../agents/${decision.agent}`);
    const result = await mod.dispatch({ uuid:call.uuid, prompt:call.prompt, intent:call.intent, context:call.context });
    const ms = Date.now()-t0;
    jaaDB.update('agent_calls', call.uuid, { status:'complete', response:result?.text||result?.response||JSON.stringify(result)||'', completedAt:Date.now(), latencyMs:ms });
    _updateW(decision.cluster, decision.agent, true, ms);
    return result;
  } catch(e) {
    jaaDB.update('agent_calls', call.uuid, { status:'pending_external', routedTo:decision.agent });
    _updateW(decision.cluster, decision.agent, false, Date.now()-t0);
    _failures.push({ uuid:call.uuid, cluster:decision.cluster, agent:decision.agent, error:e.message });
    throw e;
  }
}

// ── Poll loop ─────────────────────────────────────────────────────────────────

let _interval=null, _hTimer=null, _bTimer=null, _systemState={};

async function _tick() {
  try {
    const pending = jaaDB.query('agent_calls', r=>r.status==='pending', 20);
    if (!pending.length) return;
    const snap = Object.fromEntries(Object.entries(_health).map(([k,v])=>[k,{...v}]));
    for (const call of pending) {
      jaaDB.update('agent_calls', call.uuid, { status:'processing', claimedBy:MODULE_ID, claimedAt:Date.now() });
      const c = jaaDB.get('agent_calls', call.uuid);
      if (!c || c.claimedBy !== MODULE_ID) continue;
      const d = _decide(call, snap, _weights);
      jaaDB.update('agent_calls', call.uuid, { status:'dispatched', routedTo:d.agent, routeReason:d.reason, routeCluster:d.cluster, routedAt:Date.now() });
      jaaDB.insert('event_log', { uuid:uid(), type:'raid.dispatched', payload:JSON.stringify({callUuid:call.uuid,agent:d.agent,reason:d.reason,cluster:d.cluster}), source:MODULE_ID, causedBy:call.uuid, ts:Date.now() });
      console.log(`[raid] dispatch → ${d.agent} (cluster:${d.cluster}, ${d.reason}) — call ${call.uuid.slice(0,8)}`);
      _dispatch(call, d).catch(err=>{
        jaaDB.update('agent_calls',call.uuid,{status:'failed',error:err.message});
        jaaDB.insert('failures',{uuid:uid(),source:MODULE_ID,error:err.message,stack:err.stack,causedBy:call.uuid,ts:Date.now()});
        _failures.push({uuid:call.uuid,cluster:d.cluster,agent:d.agent,error:err.message});
        _updateW(d.cluster,d.agent,false,0);
      });
    }
  } catch(err) {
    jaaDB.insert('failures',{uuid:uid(),source:MODULE_ID,error:err.message,stack:err.stack,ts:Date.now()});
  }
}

function _initESSBindings() {
  if (!_ess) return;
  for (const name of ['ollama','guardian-claude','guardian-chatgpt','claude','chatgpt']) {
    if (_ess.hasRole(name)) continue;
    try {
      const ap = require.resolve(`../agents/${name}/index`);
      const h  = _ess.write(name, async call => require(ap).dispatch(call), {input:{required:['uuid']}});
      _ess.bind(name, h);
    } catch(_) {}
  }
}

function init(cfg={}) {
  _cfg = cfg;
  _loadWeights();
  _initESSBindings();
  const _refreshHealthPromise = _refreshHealth();
  _interval = setInterval(_tick,         _cfg.pollMs??3000); _interval.unref();
  _hTimer   = setInterval(_refreshHealth, _raidCfg().healthPollMs);   _hTimer.unref();
  _bTimer   = setInterval(_brainTick,    60000);             _bTimer.unref();
  console.log(`[raid] v${VERSION} — control layer for ALL agent dispatch (LAW_I local-first, LAW_II memory-before-dispatch)`);
  console.log(`[raid]   weights:${_weights.size} learned routes · ESS:${_ess?'on':'off'} · SNR pre-filter active`);
  _refreshHealthPromise.then(() => {
    const up = ['ollama','guardian-claude','guardian-chatgpt'].filter(k => _health[k]?.online);
    console.log(`[raid]   agent health probe: ${up.length ? up.join(', ') + ' online' : 'no agents reachable yet'}`);
  });
}

function stop() { [_interval,_hTimer,_bTimer].forEach(t=>t&&clearInterval(t)); _interval=_hTimer=_bTimer=null; }
function setSystemState(s) { _systemState=s||{}; }
function getState() { return { version:VERSION, health:_health, weights:Object.fromEntries(_weights), essEnabled:!!_ess, weightCount:_weights.size }; }

// ── Tool approval gate ───────────────────────────────────────────────────────
// _approveTool(): the choke point any module wanting to execute a command
// (not just dispatch an LLM call) routes through first. Reuses
// cortex/contract/index.js's existing CONTRACTS — one source of truth for
// "what is this agent allowed to do," not a second tools.json. Fail-closed:
// an unregistered source is denied, never default-approved, since this
// gates real command execution, the highest-risk surface in the system.
const _toolHealth = {}; // { [source]: { calls: [{ts}], denials: number } }

function _approveTool(source, command, opts = {}) {
  if (!source || typeof source !== 'string') {
    return { approved: false, reason: 'source is required' };
  }
  let contractModule, contract;
  try {
    contractModule = require('../../contract');
    contract = contractModule.getContract(source);
  } catch (e) {
    return { approved: false, reason: `contract lookup failed: ${e.message}` };
  }
  // §FIX: getContract() never returns falsy — unregistered sources silently
  // fall back to CONTRACTS['_default'] (checked directly in
  // cortex/contract/index.js before writing this). _default already denies
  // 'tool' in its denied_actions, so the check below still fails closed for
  // tool calls specifically — but don't claim "no contract" when there IS
  // one (just a minimal-trust one). Flag explicitly when this is the
  // fallback, so callers/logs can tell "registered but denied" apart from
  // "not registered at all."
  const isUnregistered = !(source.toLowerCase() in (contractModule.CONTRACTS || {}));

  const action = opts.action || 'tool';
  if (contract.denied_actions?.includes(action)) {
    return { approved: false, reason: isUnregistered
      ? `source '${source}' has no contract — fell back to minimal-trust default, which denies '${action}'`
      : `'${action}' is explicitly denied for ${source}` };
  }
  if (!contract.allowed_actions?.includes(action)) {
    return { approved: false, reason: `'${action}' is not in ${source}'s allowed_actions` };
  }

  // Rate limiting — same shape as contract.rate_limits, per-source tracked
  // here rather than in contract.js itself, since this is call-frequency
  // state, not the static permission definition.
  const now = Date.now();
  const health = _toolHealth[source] || (_toolHealth[source] = { calls: [], denials: 0 });
  const limit = contract.rate_limits?.[action] || contract.rate_limits?.['*'];
  if (limit) {
    health.calls = health.calls.filter(c => now - c.ts < limit.windowMs);
    if (health.calls.length >= limit.max) {
      health.denials++;
      return { approved: false, reason: `rate limit exceeded for ${source}/${action} — ${limit.max} per ${limit.windowMs}ms`, retryAfterMs: limit.windowMs - (now - health.calls[0].ts) };
    }
  }

  if (contract.proof_required && !opts.proof) {
    return { approved: false, reason: `${source} requires proof for tool calls, none supplied` };
  }

  health.calls.push({ ts: now, command: typeof command === 'string' ? command.slice(0, 200) : null });
  return { approved: true, source, action, trust_level: contract.trust_level };
}

function _toolHealthSnapshot() {
  const out = {};
  for (const [source, h] of Object.entries(_toolHealth)) {
    out[source] = { recentCalls: h.calls.length, denials: h.denials };
  }
  return out;
}

module.exports = { init, stop, getState, setSystemState, _decide, _cluster, _health, _weights, _updateW, _approveTool, _toolHealthSnapshot };
