// ==UserScript==
// @name         Guardian — Gemini v10.0
// @namespace    nexus.guardian.gemini
// @version      10.1.0
// @description  Guardian v10 — Gemini: protocol parity with Claude/ChatGPT v10 (NCP
//               handshake, IndexedDB kernel, SHA-256 dedup, tab-claim, SEAM jobs,
//               intelligence injection, usage detection) built around Gemini's actual
//               distinctive surface — vision, image understanding, image generation,
//               multimodal — not a copy with selectors swapped.
// @author       James Brooks / Nexus
// @match        https://gemini.google.com/*
// @match        https://aistudio.google.com/*
// @grant        GM_xmlhttpRequest
// @grant        GM_getValue
// @grant        GM_setValue
// @connect      *
// @run-at       document-idle
// ==/UserScript==

(function () {
'use strict';

// ── Constants ─────────────────────────────────────────────────────────────────
const NCP_URL     = 'http://127.0.0.1:7820';
const NCP_CHANNEL = `${NCP_URL}/channel`;
const NCP_RESULT  = `${NCP_URL}/result`;
const NCP_HB      = `${NCP_URL}/heartbeat`;
const CORTEX_URL  = 'http://127.0.0.1:3748';
const ORCH_URL    = 'http://127.0.0.1:9000';
const BRIDGE_URL  = 'http://127.0.0.1:9999';
const PROVIDER    = 'gemini';
const VERSION     = '10.0.0';
// §P113: exponential backoff 3s→30s — eliminates SSE flood on disconnect
const RECONNECT_MIN_MS = 3000;
const RECONNECT_MAX_MS = 30000;
let _reconnectAttempts = 0;
const HB_MS         = 8000;

// ── Tab identity ──────────────────────────────────────────────────────────────
const MY_TAB = sessionStorage.getItem('gd_gemini_id') || (() => {
  const id = Date.now().toString(36) + Math.random().toString(36).slice(2);
  sessionStorage.setItem('gd_gemini_id', id); return id;
})();
const TAB_KEY = 'guardian_claimed_tab_gemini';

// ── Runtime state ─────────────────────────────────────────────────────────────
let _es = null, _hb = null, _reconnectTimer = null;
let connState = 'disconnected';
let currentJobId = null, jobActive = false;
let _watchTimer = null, _watchObs = null, _watchStart = 0;
let isClaimed = true; // §FIX 2026-06-20: passive mode removed — every connected tab executes jobs, no single-tab claim gate
let sessionStart = Date.now(), sessionTokens = 0, sessionJobs = 0;
let logEntries = [], currentGaps = [], artifactStore = [], _usageHistory = [];
let accountState = null;
let _settings = {};
let _intelligenceCtx = null;

// ── §ADAPTER-CONSISTENCY — provider fingerprint, checked by tests/userscript-adapter-consistency.test.js
const _FINGERPRINT = 'gemini';

// ── IndexedDB Kernel — same contract as claude/chatgpt: requests/sessions/artifacts ──
const IDB_NAME    = 'nexus_guardian_gemini';
const IDB_VERSION = 1;
let _db = null;
function dbOpen() {
  return new Promise((res, rej) => {
    const req = indexedDB.open(IDB_NAME, IDB_VERSION);
    req.onupgradeneeded = e => {
      const db = e.target.result;
      if (!db.objectStoreNames.contains('requests')) {
        const s = db.createObjectStore('requests', { keyPath: 'uuid' });
        s.createIndex('status', 'status'); s.createIndex('sessionId', 'sessionId');
      }
      if (!db.objectStoreNames.contains('sessions')) db.createObjectStore('sessions', { keyPath: 'sessionId' });
      if (!db.objectStoreNames.contains('artifacts')) {
        const a = db.createObjectStore('artifacts', { keyPath: 'hash' });
        a.createIndex('jobId', 'jobId'); a.createIndex('ts', 'ts');
      }
    };
    req.onsuccess = e => { _db = e.target.result; res(_db); };
    req.onerror   = e => rej(e.target.error);
  });
}
function dbPut(store, obj) {
  if (!_db) return Promise.resolve(null);
  return new Promise((res, rej) => {
    const req = _db.transaction(store, 'readwrite').objectStore(store).put(obj);
    req.onsuccess = () => res(req.result); req.onerror = e => rej(e.target.error);
  });
}
function dbGet(store, key) {
  if (!_db) return Promise.resolve(null);
  return new Promise((res, rej) => {
    const req = _db.transaction(store, 'readonly').objectStore(store).get(key);
    req.onsuccess = () => res(req.result || null); req.onerror = e => rej(e.target.error);
  });
}
function dbGetAll(store, indexName, value) {
  if (!_db) return Promise.resolve([]);
  return new Promise((res, rej) => {
    const s = _db.transaction(store, 'readonly').objectStore(store);
    const req = indexName ? s.index(indexName).getAll(value) : s.getAll();
    req.onsuccess = () => res(req.result || []); req.onerror = e => rej(e.target.error);
  });
}

// ── SHA-256 dedup ──────────────────────────────────────────────────────────────
async function sha256(text) {
  try {
    const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(text));
    return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2,'0')).join('').slice(0,16);
  } catch(_) {
    let h = 0;
    for (let i = 0; i < text.length; i++) { h = Math.imul(31, h) + text.charCodeAt(i) | 0; }
    return Math.abs(h).toString(16).padStart(8,'0');
  }
}

// ── Session UUID chain ────────────────────────────────────────────────────────
let _sessionId = null;
async function getSessionId() {
  if (_sessionId) return _sessionId;
  const chatPath = location.pathname;
  const stored   = await dbGet('sessions', chatPath);
  if (stored) { _sessionId = stored.sessionId; return _sessionId; }
  _sessionId = `sess_${Date.now().toString(36)}_${Math.random().toString(36).slice(2)}`;
  await dbPut('sessions', { sessionId: _sessionId, chatPath, provider: PROVIDER, startedAt: Date.now() });
  return _sessionId;
}

async function replayPending() {
  const pending = await dbGetAll('requests', 'status', 'pending');
  if (!pending.length) return;
  _log('sys', `Replaying ${pending.length} pending request(s) from IDB`);
  for (const r of pending) {
    ncpPost(NCP_RESULT, { type: 'GUARDIAN_REPLAY', ...r }).catch(() => {});
    await dbPut('requests', { ...r, status: 'replayed', replayedAt: Date.now() });
  }
}

// ── Utils ─────────────────────────────────────────────────────────────────────
function uid()  { return Date.now().toString(36) + Math.random().toString(36).slice(2,6); }
function estimateTokens(s) { return Math.max(1, Math.round((s||'').length / 4)); }

// ── §ADAPTER — chatId — §HONEST-NOTE: gemini.google.com's conversation URL
// structure (currently /app/<id> on the consumer product, project/chat ids on
// aistudio.google.com) isn't pinned to a verified-current pattern the way
// claude's /chat/<id> and chatgpt's /c/<id> are. This is a best-effort capture,
// not a confirmed-stable contract — verify against what you actually see.
function chatId() {
  const m = location.pathname.match(/\/(?:app|chat)\/([a-zA-Z0-9_-]+)/);
  return m ? m[1] : 'home';
}

// ── §ADAPTER — getAccount ──────────────────────────────────────────────────────
function getAccount() {
  if (accountState) return accountState;
  const sels = ['[aria-label*="Google Account"]','[data-email]','a[href*="myaccount.google.com"]','[aria-label*="@"]'];
  for (const sel of sels) {
    const el = document.querySelector(sel);
    if (el) {
      const t = (el.getAttribute('aria-label')||el.getAttribute('data-email')||el.textContent||'').trim();
      if (t.includes('@') || t.length > 3) { accountState = t.slice(0,60); return accountState; }
    }
  }
  return location.hostname;
}

// ── §ADAPTER — usage/quota-limit detection ────────────────────────────────────
// §HONEST-NOTE: same caveat as claude.js/chatgpt.js — copy/markup drifts,
// this is a layered, drift-tolerant net (alert/live-region markup first,
// composer container second, disabled-composer corroboration third).
let usageState = { limited: false, message: null, resetHint: null, detectedAt: null };
const USAGE_PATTERNS = [
  /reached (the|your) .*(limit|quota)/i, /usage limit/i, /daily limit/i,
  /try again (later|tomorrow|in)/i, /upgrade to .*(advanced|pro)/i,
  /rate limit/i, /come back (later|in)/i,
];
const RESET_HINT_RE = /(reset|try again|come back)[^.]{0,60}/i;
function _composerDisabled() {
  const ta = _getInput();
  const btn = _getSendBtn();
  return !!(ta?.getAttribute('aria-disabled')==='true' || btn?.disabled);
}
function detectUsageLimit() {
  try {
    const regions = [...document.querySelectorAll('[role="alert"], [role="status"], [aria-live="polite"], [aria-live="assertive"]')];
    const composer = _getInput();
    if (composer) { const c = composer.closest('form')?.parentElement || composer.parentElement?.parentElement; if (c) regions.push(c); }
    for (const el of regions) {
      const t = (el.textContent || '').trim();
      if (!t || t.length > 400) continue;
      if (USAGE_PATTERNS.some(re => re.test(t))) {
        const resetMatch = t.match(RESET_HINT_RE);
        usageState = { limited: true, message: t.slice(0,200), resetHint: resetMatch?.[0]||null, detectedAt: Date.now() };
        return usageState;
      }
    }
    if (_composerDisabled() && usageState.limited === false) {
      usageState = { limited: 'suspected', message: 'composer disabled, no matching banner text', resetHint: null, detectedAt: Date.now() };
      return usageState;
    }
    if (usageState.limited) usageState = { limited: false, message: null, resetHint: null, detectedAt: Date.now() };
    return usageState;
  } catch(e) { return usageState; }
}

// ── §ADAPTER — DOM selectors ───────────────────────────────────────────────────
// Real selectors carried forward from the v1.0 script, not invented fresh —
// these were already considered (rich-text editor + AI Studio fallback).
function _getInput() {
  return document.querySelector('div[contenteditable="true"][aria-label]') ||
         document.querySelector('.ql-editor') ||
         document.querySelector('[data-placeholder]');
}
function _getSendBtn() {
  return document.querySelector('button[aria-label*="Send"]') ||
         document.querySelector('button[aria-label*="send"]') ||
         document.querySelector('mat-icon[fonticon="send"]')?.closest('button');
}
function findResponseEl() {
  const msgs = document.querySelectorAll('.model-response-text, .response-content, [data-testid="response"]');
  if (msgs.length) return msgs[msgs.length - 1];
  return document.querySelector('ms-chunk, .output-content'); // AI Studio
}
function _isGenerating() {
  return !!document.querySelector('.loading-indicator, .streaming-indicator, [aria-label*="Stop generating"], [aria-label*="Stop"]');
}

// ── §ADAPTER — Gemini's actual distinctive surface: vision/multimodal ────────
// This is the part that's genuinely different from Claude/ChatGPT, not boilerplate.
// extractMedia(): Gemini can both understand attached images and *generate* new
// ones (image generation in gemini.google.com and aistudio). Detect generated
// images in the response so artifacts/jobs accurately reflect non-text output —
// a text-only artifact scanner (like claude/chatgpt's scanArtifacts) would
// silently drop this for Gemini specifically.
function extractMedia(responseEl) {
  if (!responseEl) return [];
  const imgs = responseEl.querySelectorAll('img[src^="data:"], img[src*="googleusercontent"], [data-generated-image] img');
  return [...imgs].slice(0,5).map(img => ({
    type: 'image', src: img.src?.slice(0,200), alt: img.alt || null, generated: !!img.closest('[data-generated-image]'),
  }));
}
// Did the user attach an image/file to this prompt? Gemini's vision intake —
// matters for RAID: a vision-bearing job should never silently route to a
// text-only fallback provider on retry.
function hasAttachedMedia() {
  return !!document.querySelector('[data-attachment], [aria-label*="attached file"], .file-preview, .image-preview');
}

// ── Bus connections — identical contract to claude/chatgpt ───────────────────
function _toOrc(system, type, payload = {}) {
  fetch(`${ORCH_URL}/api/ledger`, { method:'POST', headers:{'Content-Type':'application/json'}, keepalive:true,
    body: JSON.stringify({ system, type, payload }) }).catch(()=>{});
}
function _toCortex(type, payload = {}) {
  fetch(`${CORTEX_URL}/api/event`, { method:'POST', headers:{'Content-Type':'application/json'}, keepalive:true,
    body: JSON.stringify({ type, payload: { ...payload, _account:getAccount(), _chatUrl:location.href },
      source:'userscript-gemini', causedBy:currentJobId||null, ts:Date.now() }) }).catch(()=>{});
}
function _toBridge(type, payload = {}) {
  fetch(`${NCP_URL}/result`, { method:'POST', headers:{'Content-Type':'application/json'}, keepalive:true,
    body: JSON.stringify({ type, ...payload, ts:Date.now() }) }).catch(()=>{});
}

// ── Gate — §1.2 ───────────────────────────────────────────────────────────────
async function gate(name, fn, opts = {}) {
  const { jobId = null } = opts;
  const t0 = Date.now();
  try {
    const result = await fn();
    _log('ok', `✓ ${name}`, `${Date.now()-t0}ms`);
    return { ok: true, result };
  } catch (e) {
    const msg = `${name}: ${e.message}`;
    _log('err', `§1.2 GATE FAIL: ${name}`, e.message);
    toast(msg, 'error', 4000);
    if (jobId) send({ type:'GUARDIAN_ERROR', jobId, gate:name, error:msg, chatUrl:location.href, account:getAccount() });
    _toCortex('guardian.gate.failed', { gate:name, error:e.message });
    return { ok: false, error: msg };
  }
}

// ── Pre-prompt intelligence injection — identical contract, provider-agnostic ─
async function pullIntelligenceContext(intent, command) {
  try {
    const url = `${CORTEX_URL}/api/intelligence/context?intent=${encodeURIComponent((intent||'').slice(0,120))}&command=${encodeURIComponent(command||'')}&provider=${PROVIDER}`;
    const r = await fetch(url, { signal: AbortSignal.timeout(3000) });
    if (!r.ok) return null;
    _intelligenceCtx = await r.json();
    return _intelligenceCtx;
  } catch(_) { return null; }
}
function buildContextHeader(ctx) {
  if (!ctx) return '';
  const parts = [];
  if (ctx.failureModes?.length) parts.push(`[KNOWN FAILURE MODES — account for these]\n` + ctx.failureModes.slice(0,3).map(f => `  - ${f.faultClass} (×${f.count}): ${f.note||''}`).join('\n'));
  if (ctx.reuse?.length) parts.push(`[REUSABLE ARTIFACTS — check before reimplementing]\n` + ctx.reuse.slice(0,2).map(r => `  - ${r.type} [${r.lang||'?'}] hash:${r.hash} — ${r.intent||''}`).join('\n'));
  if (ctx.patterns?.filter(p => p.actionable).length) parts.push(`[ACTIVE PATTERNS]\n` + ctx.patterns.filter(p => p.actionable).slice(0,2).map(p => `  - ${p.description}`).join('\n'));
  if (ctx.systemState?.criticalGaps > 0) parts.push(`[SYSTEM STATE] ${ctx.systemState.criticalGaps} critical gaps open — types: ${ctx.systemState.topGapTypes?.join(', ')||'?'}`);
  return parts.length ? `[NEXUS CONTEXT]\n${parts.join('\n')}\n\n` : '';
}

// ── NCP post helper ───────────────────────────────────────────────────────────
async function ncpPost(url, data) {
  try {
    const res = await fetch(url, { method:'POST', headers:{'Content-Type':'application/json'}, keepalive:true,
      body: JSON.stringify({ ...data, chatUrl: location.href, account: getAccount() }) });
    return res.ok ? await res.json() : null;
  } catch(_) { return null; }
}
function send(obj) { ncpPost(NCP_RESULT, obj).catch(()=>{}); }
function sendLedger(category, msg, meta={}) {
  send({ type:'GUARDIAN_LEDGER_EVENT', level:category, category, msg, meta, chatUrl:location.href, account:getAccount(), requestId:currentJobId });
}

// ── Log + toast ───────────────────────────────────────────────────────────────
function _log(type, msg, detail) { logEntries.push({ ts:Date.now(), type, msg, detail:detail||null }); if (logEntries.length>300) logEntries.shift(); console.log(`[guardian-gemini] ${type}: ${msg}`, detail||''); }
function toast(msg, type='info', ms=3000) {
  const C = { success:'#34d399', error:'#f87171', warn:'#f59e0b', job:'#fbbf24', info:'#818cf8' };
  const el = document.createElement('div');
  el.style.cssText = `position:fixed;bottom:80px;right:20px;z-index:2147483647;background:rgba(8,8,14,.95);border:1px solid ${C[type]||C.info}44;color:${C[type]||C.info};padding:8px 14px;border-radius:6px;font:600 11px monospace;box-shadow:0 4px 20px rgba(0,0,0,.6);max-width:340px`;
  el.textContent = msg; document.body.appendChild(el); setTimeout(() => el.remove(), ms);
}

// ── Streaming to cortex ───────────────────────────────────────────────────────
let _streamBuf = '', _streamCnt = 0;
function _streamToCortex(jobId, delta, full) {
  _streamBuf += delta; _streamCnt++;
  if (_streamBuf.length < 400 && _streamCnt % 5 !== 0 && !/[.!?\n]$/.test(delta)) return;
  const batch = _streamBuf; _streamBuf = '';
  _toCortex('guardian.job.stream', { jobId, provider:PROVIDER, text:batch.slice(0,2000), chars:batch.length, fullLen:(full||'').length, chatUrl:location.href });
}

function recordUsage(jobId, text, ms) {
  const tokens = estimateTokens(text);
  sessionTokens += tokens; sessionJobs++;
  const u = { jobId, chatId:chatId(), chars:text.length, tokens, ms, ts:Date.now(), retried:false };
  _usageHistory.push(u); if (_usageHistory.length > 50) _usageHistory.shift();
  return u;
}

// ── Artifact detection — text (dedup) + media (Gemini-specific) ──────────────
let _seenHashes = new Set();
async function scanArtifacts(jobId, responseEl) {
  const codeEls = document.querySelectorAll('pre code, .code-block code, [class*="CodeBlock"] code');
  for (const el of codeEls) {
    const content = (el.innerText || el.textContent || '').trim();
    if (content.length < 50) continue;
    const hash = await sha256(content);
    if (_seenHashes.has(hash)) continue;
    const existing = await dbGet('artifacts', hash);
    if (existing) { _seenHashes.add(hash); continue; }
    _seenHashes.add(hash);
    const cls = el.closest('pre')?.querySelector('[class*="language-"]')?.className?.match(/language-(\w+)/)?.[1] || 'text';
    const art = { hash, lang: cls, content: content.slice(0,4000), jobId, provider:PROVIDER, sessionId: await getSessionId(), ts: Date.now() };
    await dbPut('artifacts', art);
    artifactStore.push(art); if (artifactStore.length > 200) artifactStore.shift();
    send({ type:'GUARDIAN_ARTIFACT', jobId, content:art.content, lang:cls, hash, chatUrl:location.href, account:getAccount() });
    _toCortex('guardian.artifact', { jobId, hash, lang:cls, chars:content.length });
    _log('ok', `Artifact: ${cls} ${hash}`, `${content.length}ch`);
  }
  // §ADAPTER — Gemini-specific: media artifacts (generated images)
  const media = extractMedia(responseEl);
  if (media.length) {
    send({ type:'GUARDIAN_ARTIFACT', jobId, kind:'media', media, chatUrl:location.href, account:getAccount() });
    _toCortex('guardian.artifact.media', { jobId, count:media.length, generated:media.some(m=>m.generated) });
    _log('ok', `Media artifact(s): ${media.length}`, media.some(m=>m.generated) ? 'generated' : 'attached');
  }
}

// ── Inject + submit ────────────────────────────────────────────────────────────
function injectText(text) {
  const inp = _getInput();
  if (!inp) return false;
  inp.focus();
  document.execCommand('selectAll', false, null);
  document.execCommand('insertText', false, text);
  inp.dispatchEvent(new Event('input', { bubbles: true }));
  inp.dispatchEvent(new Event('change', { bubbles: true }));
  return true;
}
function submit() {
  const btn = _getSendBtn();
  if (btn && !btn.disabled) { btn.click(); return; }
  const inp = _getInput();
  if (inp) inp.dispatchEvent(new KeyboardEvent('keydown', { key:'Enter', keyCode:13, bubbles:true, cancelable:true }));
}

// ── Gap / error detection — same contract as claude/chatgpt ──────────────────
function detectResponseErrors(text) {
  const issues = [];
  if (/\bcannot\s+assist|\bcannot\s+help|\bunable to\b/i.test(text)) issues.push({type:'refusal',score:0.9,reason:'refusal detected'});
  if (/\bcontext window\b|\btoken limit\b|\btoo long\b/i.test(text)) issues.push({type:'context_limit',score:0.9,reason:'context limit'});
  if (/\bsorry\b|\bapologize\b/i.test(text)&&text.length<200) issues.push({type:'short_apology',score:0.6,reason:'short apology'});
  if (text.length < 80 && jobActive) issues.push({type:'truncation',score:0.7,reason:'very short response'});
  if ((text.match(/```/g)||[]).length % 2 !== 0) issues.push({type:'unclosed_code_block',score:0.8,reason:'unclosed code block'});
  return issues;
}
function autoRetry(jobId, text, retryCount) {
  const issue = detectResponseErrors(text)[0];
  if (!issue || retryCount >= 2) return;
  const retryPrompts = {
    context_limit: 'The previous response hit a context limit. Please summarise what was completed and list exactly what remains.',
    truncation: 'Your response was cut off. Please continue from exactly where you stopped.',
    refusal: 'Please reconsider and provide the technical assistance requested.',
    unclosed_code_block: 'Your last code block was not closed. Please complete it.',
    short_apology: 'Please provide a full technical response rather than an apology.',
  };
  const retry = retryPrompts[issue.type] || `Issue detected (${issue.type}). Please revise your response.`;
  _log('gap', `Auto-retry: ${issue.type}`, `attempt ${retryCount+1}`);
  setTimeout(() => {
    if (!injectText(retry)) return;
    setTimeout(submit, 500);
    startWatch(jobId, retry, retryCount+1);
  }, 1000);
}

// ── Watch / stream loop — same MutationObserver contract as claude/chatgpt ───
function stopWatch() {
  if (_watchObs) { _watchObs.disconnect(); _watchObs = null; }
  if (_watchTimer) { clearTimeout(_watchTimer); _watchTimer = null; }
  currentJobId = null; jobActive = false;
}
function startWatch(jobId, prompt, retryCount = 0) {
  stopWatch();
  currentJobId = jobId; jobActive = true; _watchStart = Date.now();
  let lastText = '', stableCount = 0, _lastChunkLen = 0;

  function checkStable() {
    if (!currentJobId || currentJobId !== jobId) return;
    const el = findResponseEl();
    if (!el) { _watchTimer = setTimeout(checkStable, 600); return; }
    const text = (el.innerText || el.textContent || '').trim();
    if (text === lastText && !_isGenerating()) {
      stableCount++;
      if (stableCount >= 3) { const ms = Date.now() - _watchStart; _onJobComplete(jobId, text, el, ms, prompt, retryCount); return; }
    } else {
      if (text.length > _lastChunkLen) {
        const delta = text.slice(_lastChunkLen); _lastChunkLen = text.length;
        if (delta.length > 10 || /[.!?\n]/.test(delta)) {
          send({ type:'GUARDIAN_CHUNK', jobId, text:delta, full:text, provider:PROVIDER, chatUrl:location.href, ts:Date.now() });
          _streamToCortex(jobId, delta, text);
        }
      }
      lastText = text; stableCount = 0;
    }
    _watchTimer = setTimeout(checkStable, 300);
  }
  const target = document.querySelector('main') || document.body;
  _watchObs = new MutationObserver(() => {
    stableCount = 0;
    if (_watchTimer) { clearTimeout(_watchTimer); _watchTimer = null; }
    _watchTimer = setTimeout(checkStable, 300);
  });
  _watchObs.observe(target, { childList:true, subtree:true, characterData:true });
  _watchTimer = setTimeout(checkStable, 1500);
}

async function _onJobComplete(jobId, text, responseEl, ms, prompt, retryCount) {
  stopWatch();
  send({ type:'GUARDIAN_LEDGER_WRITE', jobId, category:'UPGRADE', msg:`Complete · ${text.length}ch · ${Math.round(ms/1000)}s`,
    meta:{ jobId, chars:text.length, ms, provider:PROVIDER, ts:Date.now() } });
  _log('ok', `Complete · ${text.length}ch`, `${Math.round(ms/1000)}s · #${jobId.slice(0,8)}`);
  toast(`Done: ${text.length}ch in ${Math.round(ms/1000)}s`, 'success', 3500);

  const usage = recordUsage(jobId, text, ms);
  await scanArtifacts(jobId, responseEl);
  await dbPut('requests', { uuid:jobId, status:'fulfilled', completedAt:Date.now(), sessionId:await getSessionId() });

  const issues = detectResponseErrors(text);
  if (issues.length) {
    currentGaps = [...issues, ...currentGaps].slice(0,100);
    if (retryCount === 0) autoRetry(jobId, text, retryCount);
    send({ type:'GUARDIAN_GAPS', jobId, gaps:issues, chatUrl:location.href, account:getAccount() });
    _toCortex('cortex.gap.found', { jobId, gaps:issues, source:'userscript-detector' });
  }

  const media = extractMedia(responseEl);
  send({ type:'GUARDIAN_COMPLETE', jobId, text, media, chatUrl:location.href, account:getAccount(), requestId:jobId });
  _toCortex('guardian.job.complete', { jobId, chars:text.length, ms, usage, mediaCount:media.length });
  _toBridge('guardian.job.complete', { jobId, chars:text.length, ms, provider:PROVIDER });
  sendLedger('UPGRADE', `Job complete · #${jobId.slice(0,8)}`, { jobId, chars:text.length, ms });
}

// ── Job handler ───────────────────────────────────────────────────────────────
async function handleJob(msg) {
  const { jobId, prompt='', content='', command='' } = msg;
  const text = content ? (prompt ? `${prompt}\n\n${content}` : content) : prompt;
  if (!text.trim()) { _log('err','Empty job','skipping'); return; }

  const sessionId = await getSessionId();
  await dbPut('requests', { uuid:jobId, status:'pending', command, promptLen:text.length, sessionId, provider:PROVIDER, createdAt:Date.now() });
  send({ type:'GUARDIAN_LEDGER_WRITE', jobId, category:'INPUT', msg:`Job: ${command} #${jobId.slice(0,8)}`,
    meta:{ jobId, command, chars:text.length, provider:PROVIDER, chatUrl:location.href, ts:Date.now() } });
  _log('job', `Job: ${command}`, `${text.length}ch · #${jobId.slice(0,8)}`);
  toast(`⚡ ${command} · #${jobId.slice(0,8)}`, 'job', 3000);
  _toCortex('agent.call.start', { jobId, provider:PROVIDER, command, promptLen:text.length, hasMedia: hasAttachedMedia() });
  _toBridge('guardian.job.dispatched', { jobId, command, provider:PROVIDER });

  await gate('handleJob', async () => {
    const intel    = await pullIntelligenceContext(text, command);
    const intelHdr = buildContextHeader(intel);
    const finalText = intelHdr + text;
    if (!injectText(finalText)) throw new Error('Input not found — Gemini composer not detected');
    send({ type:'GUARDIAN_DELIVERED', jobId, chatUrl:location.href, account:getAccount(), requestId:jobId });
    await dbPut('requests', { uuid:jobId, status:'dispatched', sessionId, dispatchedAt:Date.now() });
    setTimeout(() => { submit(); startWatch(jobId, text, 0); }, 800);
    return true;
  }, { jobId });
}

// ── Tab claim ─────────────────────────────────────────────────────────────────
function amIClaimed() { return GM_getValue(TAB_KEY,'') === MY_TAB; }
function claimTab()   { GM_setValue(TAB_KEY, MY_TAB); isClaimed = true; updatePill(); }
function releaseTab() { /* no-op — passive mode removed, tabs stay active */ }
function autoClaimIfFree() {
  const ex = GM_getValue(TAB_KEY,'');
  if (!ex) { claimTab(); return; }
  const last = GM_getValue('gd_hb_'+ex, 0);
  if (Date.now() - last > 15000) { GM_setValue(TAB_KEY,''); claimTab(); }
}
setInterval(() => GM_setValue('gd_hb_'+MY_TAB, Date.now()), 5000);

// ── NCP connection ────────────────────────────────────────────────────────────
function connect() {
  if (_reconnectTimer) { clearTimeout(_reconnectTimer); _reconnectTimer = null; }
  _reconnectAttempts = 0; // §P113: reset backoff on successful connect
  if (_es) { try { _es.close(); } catch(_) {} }
  const params = `tabId=${MY_TAB}&provider=${PROVIDER}`;
  connState = 'connecting'; updatePill();
  _es = new EventSource(`${NCP_CHANNEL}?${params}`);
  _es.onmessage = e => { try { _handleServerMessage(JSON.parse(e.data)); } catch(err) { _log('err','NCP parse',err.message); } };
  _es.onopen = () => {
    connState = 'ready'; updatePill();
    _log('ok', `NCP connected · ${PROVIDER}`, NCP_CHANNEL);
    ncpPost(NCP_RESULT, { type:'GUARDIAN_REGISTER', provider:PROVIDER, host:location.hostname, tabId:MY_TAB, claimed:amIClaimed() });
    if (_hb) clearInterval(_hb);
    _hb = setInterval(() => ncpPost(NCP_HB, { type:'GUARDIAN_HEARTBEAT', provider:PROVIDER, tabId:MY_TAB, ts:Date.now(), usage:detectUsageLimit(), chatId:chatId(), claimed:isClaimed }), HB_MS);
    autoClaimIfFree();
    replayPending();
  };
  _es.onerror = () => {
    connState = 'disconnected'; updatePill();
    _reconnectAttempts++;
    const _delay = Math.min(RECONNECT_MIN_MS * Math.pow(2, _reconnectAttempts - 1), RECONNECT_MAX_MS);
    _log('err', `NCP error — retry ${_delay}ms (attempt ${_reconnectAttempts})`);
    _es.close(); clearInterval(_hb);
    _reconnectTimer = setTimeout(connect, _delay);
  };
}
function _handleServerMessage(msg) {
  switch(msg.type) {
    case 'NCP_READY': case 'GUARDIAN_READY': connState='ready'; updatePill(); toast('Guardian connected ✓','success',2000); break;
    case 'GUARDIAN_CLAIM':
      if (msg.tabId===MY_TAB||msg.tabId==='any') { claimTab(); ncpPost(NCP_RESULT,{type:'GUARDIAN_CLAIM_ACK',tabId:MY_TAB,provider:PROVIDER}); toast('Tab claimed — ACTIVE','success',2000); }
      break;
    case 'GUARDIAN_RELEASE': releaseTab(); break;
    case 'GUARDIAN_JOB': currentJobId = msg.jobId; handleJob(msg); break;
    case 'NEXUS_CONTEXT_RESPONSE': if (msg.context) _intelligenceCtx = msg.context; break;
    default: _log('debug', `NCP: ${msg.type}`);
  }
}

// Navigation tracking
let _lastPath = location.pathname;
setInterval(() => {
  if (location.pathname !== _lastPath) {
    _lastPath = location.pathname; _sessionId = null;
    if (currentJobId) stopWatch();
    _log('sys', `Nav → ${chatId()}`);
  }
}, 1000);

// ── Minimal status widget — protocol-state visibility, not the full debug panel ─
// (9-tab observability layer deferred per scope split — this is the
// equivalent of v1's status pill, upgraded to reflect claim/protocol state.)
let _pill = null;
function updatePill() {
  if (!_pill) return;
  const col = connState!=='ready' ? '#ff2d55' : '#00ff88';
  _pill.style.borderColor = col;
  _pill.textContent = `⬡ Gemini · ${connState} · ACTIVE`;
}
function _injectWidget() {
  _pill = document.createElement('div');
  _pill.style.cssText = 'position:fixed;bottom:12px;right:12px;z-index:2147483647;background:#05080f;border:1px solid #00ff88;border-radius:4px;padding:6px 10px;font:10px monospace;color:#e0e8ff;user-select:none;cursor:pointer;opacity:.85';
  _pill.title = `Guardian NCP — Gemini v${VERSION}\nTab: ${MY_TAB}`;
  _pill.onclick = () => {}; // passive mode removed — nothing to toggle
  document.body.appendChild(_pill);
  updatePill();
}

// ── Init ──────────────────────────────────────────────────────────────────────
async function init() {
  await dbOpen().catch(() => { _log('err','IDB failed — degraded mode'); });
  _injectWidget();
  connect();
  _log('sys', `Guardian v${VERSION} — Gemini`, `${PROVIDER} · ${location.hostname}`);
}
if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
else init().catch(e => console.error('[Guardian §1.2]', e));

})();
