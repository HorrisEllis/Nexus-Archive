'use strict';

/**
 * ClearDriver — NEXUS sovereign browser automation
 * No Playwright. No Puppeteer. Own the primitives.
 * 
 * Commands arrive as NEXUS bus messages.
 * Results stream back on SSE.
 * All actions are CFR-logged with intent/agent/progress.
 */

const { BrowserWindow, webContents } = require('electron');
const { v4: uuidv4 } = require('uuid');

class ClearDriver {
  constructor({ ctxMgr, dom, vault, sse }) {
    this.ctxMgr = ctxMgr;
    this.dom    = dom;
    this.vault  = vault;
    this.sse    = sse;
    this.queue  = new Map(); // agentId → action queue
  }

  // ── Primary dispatch ──────────────────────────────────────────────────
  async exec(payload) {
    const { action, agentId = 'default', ...args } = payload;
    const execId = uuidv4();

    this.sse.emit('driver.start', { execId, action, agentId, ts: Date.now() });

    let result;
    try {
      result = await this._dispatch(action, agentId, args, execId);
      this.sse.emit('driver.result', { execId, action, agentId, result, ts: Date.now() });
    } catch (err) {
      this.sse.emit('driver.error', { execId, action, agentId, error: err.message, ts: Date.now() });
      throw err;
    }

    return result;
  }

  async _dispatch(action, agentId, args, execId) {
    switch (action) {
      case 'navigate':       return this._navigate(agentId, args);
      case 'click':          return this._click(agentId, args);
      case 'type':           return this._type(agentId, args);
      case 'scroll':         return this._scroll(agentId, args);
      case 'hover':          return this._hover(agentId, args);
      case 'wait':           return this._wait(agentId, args);
      case 'waitFor':        return this._waitFor(agentId, args);
      case 'screenshot':     return this._screenshot(agentId, args);
      case 'eval':           return this._eval(agentId, args);
      case 'getUrl':         return this._getUrl(agentId);
      case 'getTitle':       return this._getTitle(agentId);
      case 'back':           return this._back(agentId);
      case 'forward':        return this._forward(agentId);
      case 'reload':         return this._reload(agentId);
      case 'cookies.get':    return this._getCookies(agentId, args);
      case 'cookies.set':    return this._setCookie(agentId, args);
      case 'cookies.clear':  return this._clearCookies(agentId, args);
      case 'storage.get':    return this._storageGet(agentId, args);
      case 'storage.set':    return this._storageSet(agentId, args);
      case 'network.block':  return this._networkBlock(agentId, args);
      case 'network.intercept': return this._networkIntercept(agentId, args);
      case 'picker.enable':  return this._enablePicker(agentId);
      case 'picker.disable': return this._disablePicker(agentId);
      case 'inject':         return this._inject(agentId, args);
      case 'record.start':   return this._recordStart(agentId, args);
      case 'record.stop':    return this._recordStop(agentId);
      default:
        throw new Error(`Unknown driver action: ${action}`);
    }
  }

  // ── Navigation ────────────────────────────────────────────────────────
  async _navigate(agentId, { url, waitUntil = 'domcontentloaded' }) {
    const wc = this._getWebContents(agentId);
    if (!wc) throw new Error(`No webcontents for agent: ${agentId}`);

    return new Promise((resolve, reject) => {
      const timeout = setTimeout(() => reject(new Error('Navigate timeout')), 30000);

      wc.once('did-finish-load', () => {
        clearTimeout(timeout);
        this.sse.emit('nav.loaded', { agentId, url: wc.getURL(), ts: Date.now() });
        resolve({ url: wc.getURL(), title: wc.getTitle() });
      });

      wc.once('did-fail-load', (e, code, desc) => {
        clearTimeout(timeout);
        reject(new Error(`Navigation failed: ${desc} (${code})`));
      });

      wc.loadURL(url);
      this.sse.emit('nav.started', { agentId, url, ts: Date.now() });
    });
  }

  // ── Click ─────────────────────────────────────────────────────────────
  async _click(agentId, { selector, x, y, button = 'left', delay = 0 }) {
    const wc = this._getWebContents(agentId);
    if (!wc) throw new Error(`No webcontents for agent: ${agentId}`);

    if (selector) {
      // Resolve element position via DOM
      const pos = await this._evalJs(wc, `
        (function() {
          const el = document.querySelector(${JSON.stringify(selector)});
          if (!el) return null;
          const r = el.getBoundingClientRect();
          return { x: r.left + r.width/2, y: r.top + r.height/2 };
        })()
      `);
      if (!pos) throw new Error(`Element not found: ${selector}`);
      x = pos.x; y = pos.y;
    }

    if (x === undefined || y === undefined) throw new Error('selector or x,y required for click');

    // Human-like timing variance
    if (delay > 0) await this._sleep(delay + Math.random() * 50);

    wc.sendInputEvent({ type: 'mouseMove', x, y });
    await this._sleep(30 + Math.random() * 30);
    wc.sendInputEvent({ type: 'mouseDown', x, y, button, clickCount: 1 });
    await this._sleep(50 + Math.random() * 50);
    wc.sendInputEvent({ type: 'mouseUp', x, y, button, clickCount: 1 });

    return { clicked: { x, y, selector } };
  }

  // ── Type ──────────────────────────────────────────────────────────────
  async _type(agentId, { selector, text, clearFirst = false, delay = 50 }) {
    const wc = this._getWebContents(agentId);
    if (!wc) throw new Error(`No webcontents for agent: ${agentId}`);

    if (selector) await this._click(agentId, { selector });
    if (clearFirst) {
      wc.sendInputEvent({ type: 'keyDown', keyCode: 'A', modifiers: ['control'] });
      await this._sleep(50);
    }

    for (const char of text) {
      wc.sendInputEvent({ type: 'keyDown', keyCode: char });
      wc.sendInputEvent({ type: 'char', keyCode: char });
      wc.sendInputEvent({ type: 'keyUp', keyCode: char });
      await this._sleep(delay + Math.random() * 30 - 15);
    }

    return { typed: text.length };
  }

  // ── Scroll ────────────────────────────────────────────────────────────
  async _scroll(agentId, { x = 0, y = 0, deltaX = 0, deltaY = 100 }) {
    const wc = this._getWebContents(agentId);
    if (!wc) throw new Error(`No webcontents for agent: ${agentId}`);
    wc.sendInputEvent({ type: 'mouseWheel', x, y, deltaX, deltaY, wheelTicksX: 0, wheelTicksY: 1 });
    return { scrolled: { deltaX, deltaY } };
  }

  // ── Hover ─────────────────────────────────────────────────────────────
  async _hover(agentId, { selector, x, y }) {
    const wc = this._getWebContents(agentId);
    if (!wc) throw new Error(`No webcontents for agent: ${agentId}`);

    if (selector) {
      const pos = await this._evalJs(wc, `
        (function() {
          const el = document.querySelector(${JSON.stringify(selector)});
          if (!el) return null;
          const r = el.getBoundingClientRect();
          return { x: r.left + r.width/2, y: r.top + r.height/2 };
        })()
      `);
      if (pos) { x = pos.x; y = pos.y; }
    }

    wc.sendInputEvent({ type: 'mouseMove', x: x || 0, y: y || 0 });
    return { hovered: { x, y } };
  }

  // ── Wait ──────────────────────────────────────────────────────────────
  async _wait(agentId, { ms = 1000 }) {
    await this._sleep(ms);
    return { waited: ms };
  }

  async _waitFor(agentId, { selector, timeout = 10000 }) {
    const wc  = this._getWebContents(agentId);
    if (!wc) throw new Error(`No webcontents for agent: ${agentId}`);

    const start = Date.now();
    while (Date.now() - start < timeout) {
      const found = await this._evalJs(wc, `!!document.querySelector(${JSON.stringify(selector)})`);
      if (found) return { found: true, elapsed: Date.now() - start };
      await this._sleep(200);
    }
    throw new Error(`WaitFor timeout: ${selector}`);
  }

  // ── Screenshot ────────────────────────────────────────────────────────
  async _screenshot(agentId, { rect } = {}) {
    const wc = this._getWebContents(agentId);
    if (!wc) throw new Error(`No webcontents for agent: ${agentId}`);

    const image = await wc.capturePage(rect);
    const png   = image.toPNG();
    const b64   = png.toString('base64');

    this.sse.emit('driver.screenshot', { agentId, data: b64, ts: Date.now() });
    return { screenshot: b64, format: 'png' };
  }

  // ── Eval ──────────────────────────────────────────────────────────────
  async _eval(agentId, { code, worldId }) {
    const wc = this._getWebContents(agentId);
    if (!wc) throw new Error(`No webcontents for agent: ${agentId}`);
    const result = await this._evalJs(wc, code, worldId);
    return { result };
  }

  // ── URL / Title ───────────────────────────────────────────────────────
  async _getUrl(agentId) {
    const wc = this._getWebContents(agentId);
    return { url: wc?.getURL() || null };
  }

  async _getTitle(agentId) {
    const wc = this._getWebContents(agentId);
    return { title: wc?.getTitle() || null };
  }

  // ── Navigation controls ───────────────────────────────────────────────
  async _back(agentId) {
    const wc = this._getWebContents(agentId);
    if (wc?.canGoBack()) wc.goBack();
    return { ok: true };
  }

  async _forward(agentId) {
    const wc = this._getWebContents(agentId);
    if (wc?.canGoForward()) wc.goForward();
    return { ok: true };
  }

  async _reload(agentId) {
    this._getWebContents(agentId)?.reload();
    return { ok: true };
  }

  // ── Cookies ───────────────────────────────────────────────────────────
  async _getCookies(agentId, { url, name } = {}) {
    const ctx = await this.ctxMgr.ensureContext(agentId);
    const filter = {};
    if (url)  filter.url  = url;
    if (name) filter.name = name;
    const cookies = await ctx.session.cookies.get(filter);
    return { cookies };
  }

  async _setCookie(agentId, { url, name, value, domain, path: p, secure, httpOnly, expirationDate }) {
    const ctx = await this.ctxMgr.ensureContext(agentId);
    await ctx.session.cookies.set({ url, name, value, domain, path: p, secure, httpOnly, expirationDate });
    return { ok: true };
  }

  async _clearCookies(agentId, { url, name } = {}) {
    const ctx = await this.ctxMgr.ensureContext(agentId);
    if (url && name) {
      await ctx.session.cookies.remove(url, name);
    } else {
      await ctx.session.clearStorageData({ storages: ['cookies'] });
    }
    return { ok: true };
  }

  // ── Storage ───────────────────────────────────────────────────────────
  async _storageGet(agentId, { key, type = 'local' }) {
    const wc = this._getWebContents(agentId);
    if (!wc) throw new Error(`No webcontents for agent: ${agentId}`);
    const result = await this._evalJs(wc, `
      (function() {
        const s = ${type === 'local' ? 'localStorage' : 'sessionStorage'};
        return ${key ? `s.getItem(${JSON.stringify(key)})` : 'Object.fromEntries(Object.entries(s))'};
      })()
    `);
    return { result };
  }

  async _storageSet(agentId, { key, value, type = 'local' }) {
    const wc = this._getWebContents(agentId);
    if (!wc) throw new Error(`No webcontents for agent: ${agentId}`);
    await this._evalJs(wc, `
      ${type === 'local' ? 'localStorage' : 'sessionStorage'}.setItem(${JSON.stringify(key)}, ${JSON.stringify(value)})
    `);
    return { ok: true };
  }

  // ── Network intercept ─────────────────────────────────────────────────
  async _networkBlock(agentId, { patterns = [] }) {
    const ctx = await this.ctxMgr.ensureContext(agentId);
    ctx.session.webRequest.onBeforeRequest({ urls: patterns }, (details, callback) => {
      callback({ cancel: true });
      this.sse.emit('driver.network.blocked', { agentId, url: details.url, ts: Date.now() });
    });
    return { blocked: patterns };
  }

  async _networkIntercept(agentId, { patterns = [], redirectUrl }) {
    const ctx = await this.ctxMgr.ensureContext(agentId);
    ctx.session.webRequest.onBeforeRequest({ urls: patterns }, (details, callback) => {
      this.sse.emit('driver.network.intercepted', { agentId, url: details.url, ts: Date.now() });
      callback(redirectUrl ? { redirectURL: redirectUrl } : {});
    });
    return { intercepting: patterns };
  }

  // ── Element picker ────────────────────────────────────────────────────
  async _enablePicker(agentId) {
    const wc = this._getWebContents(agentId);
    if (!wc) throw new Error(`No webcontents for agent: ${agentId}`);
    await this._evalJs(wc, this._pickerScript(agentId));
    return { pickerEnabled: true };
  }

  async _disablePicker(agentId) {
    const wc = this._getWebContents(agentId);
    if (!wc) return { pickerEnabled: false };
    await this._evalJs(wc, `if (window.__cgPicker) window.__cgPicker.destroy();`);
    return { pickerEnabled: false };
  }

  _pickerScript(agentId) {
    return `
(function() {
  if (window.__cgPicker) window.__cgPicker.destroy();

  const overlay = document.createElement('div');
  overlay.id = '__cg-picker-overlay';
  overlay.style.cssText = 'position:fixed;top:0;left:0;width:100%;height:100%;z-index:2147483647;cursor:crosshair;pointer-events:all;';
  document.body.appendChild(overlay);

  const highlight = document.createElement('div');
  highlight.id = '__cg-picker-highlight';
  highlight.style.cssText = 'position:fixed;pointer-events:none;z-index:2147483646;border:2px solid #00f5ff;background:rgba(0,245,255,0.08);transition:all 0.08s;box-shadow:0 0 12px #00f5ff44;';
  document.body.appendChild(highlight);

  const tooltip = document.createElement('div');
  tooltip.id = '__cg-picker-tooltip';
  tooltip.style.cssText = 'position:fixed;z-index:2147483648;background:#0a0a0f;color:#00f5ff;font:11px monospace;padding:4px 8px;border:1px solid #00f5ff44;border-radius:4px;pointer-events:none;max-width:300px;word-break:break-all;';
  document.body.appendChild(tooltip);

  let lastTarget = null;

  overlay.addEventListener('mousemove', (e) => {
    overlay.style.pointerEvents = 'none';
    const el = document.elementFromPoint(e.clientX, e.clientY);
    overlay.style.pointerEvents = 'all';
    if (!el || el === lastTarget) return;
    lastTarget = el;

    const r = el.getBoundingClientRect();
    highlight.style.top    = r.top + 'px';
    highlight.style.left   = r.left + 'px';
    highlight.style.width  = r.width + 'px';
    highlight.style.height = r.height + 'px';

    const tag  = el.tagName.toLowerCase();
    const id   = el.id ? '#' + el.id : '';
    const cls  = el.className && typeof el.className === 'string'
      ? '.' + el.className.trim().split(/\\s+/).slice(0,2).join('.') : '';
    tooltip.textContent = tag + id + cls;
    tooltip.style.left  = Math.min(e.clientX + 12, window.innerWidth - 310) + 'px';
    tooltip.style.top   = Math.min(e.clientY + 12, window.innerHeight - 40) + 'px';
  });

  overlay.addEventListener('click', (e) => {
    e.preventDefault(); e.stopPropagation();
    overlay.style.pointerEvents = 'none';
    const el = document.elementFromPoint(e.clientX, e.clientY);
    overlay.style.pointerEvents = 'all';
    if (!el) return;

    const r       = el.getBoundingClientRect();
    const tag     = el.tagName.toLowerCase();
    const id      = el.id;
    const classes = el.className;
    const text    = el.innerText?.slice(0, 100);
    const attrs   = {};
    for (const a of el.attributes) attrs[a.name] = a.value;

    // Send to main process
    if (window.__cgSendPick) {
      window.__cgSendPick({
        tag, id, classes, text, attrs,
        rect: { top: r.top, left: r.left, width: r.width, height: r.height },
        agentId: ${JSON.stringify(agentId)},
        ts: Date.now(),
      });
    }

    window.__cgPicker.destroy();
  });

  window.__cgPicker = {
    destroy() {
      overlay.remove();
      highlight.remove();
      tooltip.remove();
      window.__cgPicker = null;
    }
  };
})();
    `;
  }

  // ── Inject script ─────────────────────────────────────────────────────
  async _inject(agentId, { code, worldId, persistent = false }) {
    const wc = this._getWebContents(agentId);
    if (!wc) throw new Error(`No webcontents for agent: ${agentId}`);

    if (persistent) {
      // Re-inject on every navigation
      wc.on('did-navigate', async () => {
        await this._evalJs(wc, code, worldId).catch(() => {});
      });
    }

    const result = await this._evalJs(wc, code, worldId);
    return { result };
  }

  // ── Recording ─────────────────────────────────────────────────────────
  async _recordStart(agentId) {
    const wc = this._getWebContents(agentId);
    if (!wc) throw new Error(`No webcontents for agent: ${agentId}`);

    await this._evalJs(wc, `
      window.__cgRecording = [];
      ['click','input','change','keydown','scroll','submit'].forEach(type => {
        document.addEventListener(type, (e) => {
          const el  = e.target;
          const sel = el.id ? '#' + el.id : el.tagName.toLowerCase() + (el.className ? '.' + el.className.split(' ')[0] : '');
          window.__cgRecording.push({
            type, sel,
            value: el.value,
            ts: Date.now(),
          });
        }, true);
      });
    `);

    return { recording: true };
  }

  async _recordStop(agentId) {
    const wc = this._getWebContents(agentId);
    if (!wc) throw new Error(`No webcontents for agent: ${agentId}`);

    const recording = await this._evalJs(wc, 'window.__cgRecording || []');
    this.sse.emit('driver.recording', { agentId, recording, ts: Date.now() });
    return { recording };
  }

  // ── Internals ──────────────────────────────────────────────────────────
  _getWebContents(agentId) {
    // Find the BrowserWindow for this agent
    const all = webContents.getAllWebContents();
    // Match by agent ID stored on the window
    for (const wc of all) {
      try {
        const win = BrowserWindow.fromWebContents(wc);
        if (win && win.getTitle().includes(agentId)) return wc;
      } catch {}
    }
    // Fallback: return focused webcontents
    return webContents.getFocusedWebContents() || all[0] || null;
  }

  async _evalJs(wc, code, worldId) {
    return wc.executeJavaScript(code, true);
  }

  _sleep(ms) { return new Promise(r => setTimeout(r, ms)); }
}

module.exports = ClearDriver;
