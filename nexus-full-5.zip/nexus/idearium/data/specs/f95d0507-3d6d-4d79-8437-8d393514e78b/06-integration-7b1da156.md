---
chunk_uuid: 7b1da156-2810-43f1-b327-ba3f6c055105
spec_uuid: f95d0507-3d6d-4d79-8437-8d393514e78b
section: integration
title: Integration Points
comp_id: idearium.spec-engine
seam_id: idearium.spec-engine:v1:chunk:f95d0507:integration
contract_id: spec-contract:f95d0507:integration:7b1da156
agent: import
model: import:.spec
status: complete
completed_at: 2026-07-11T01:09:56.769Z
---

<!-- imported block: evolution log -->

# BLOCK 11 — EVOLUTION LOG
  # ════════════════════════════════════════════════════════════════
  evolution_log:
    - id: EVOL-001
      timestamp: 2026-05-24T04:00:00Z
      spec_version_before: 0.0.0
      spec_version_after: 6.0.0
      change_type: [add_module, add_invariant, add_interface]
      author: claude-sonnet-4/spec-pipeline
      reason: >
        Initial .spec encoding for causal-nexus v6.0.0. Prior state: design documented only
        in source code comments, README, and enforcement module invariant registry.
        This spec makes all 12 declared invariants (from the 29 in enforcement), all 21 modules,
        the 5-layer DAG, the dual ledger (L-1..L-4), the version-gate axioms (VM-1..VM-6),
        and the Guardian bridge interface machine-readable, queryable, and pipeline-mutable.
        Blast radius is now computable without reading code.
      alternatives_considered:
        - option: Use README + JSDoc as the spec format.
          rejected_reason: >
            README covers narrative and API surface. JSDoc has no machine-parseable causal structure,
            no invariant declarations with enforcement gates, no blast radius computation.
        - option: OpenAPI for interfaces only.
          rejected_reason: >
            OpenAPI covers external HTTP only. causal-nexus's primary contracts are internal
            (kernel → causality, persist → compress dynamic import, ledger → observer).
            These require the internal interfaces block, not OpenAPI.
      affected_modules: [identity, time, causality, projection, lazy, kernel, adapter, adapter-sandbox, observer, enforcement, delta, query, compress, persist, version-gate, context, clip, sigma, forge, loader, ledger]
      affected_invariants: [INV-I1, INV-I2, INV-C1, INV-C2, INV-C3, INV-C4, INV-A2, INV-VM1, INV-L2, INV-L4, INV-H1, INV-H6]
      causal_impact: >
        No runtime behavior change. Enables: pipeline-driven mutation, blast radius computation
        on any proposed change, drift detection against snapshots, invariant coverage verification
        (all 12 declared invariants have enforcing gates), machine-readable causal map.
      snapshot_ref: SNAP-001
      review_status: auto_approved
      reviewed_by: spec-schema-validator
      reviewed_at: 2026-05-24T04:00:00Z