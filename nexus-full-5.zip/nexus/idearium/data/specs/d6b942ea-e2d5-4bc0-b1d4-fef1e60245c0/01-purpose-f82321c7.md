---
chunk_uuid: f82321c7-a384-44de-8460-8765cf336646
spec_uuid: d6b942ea-e2d5-4bc0-b1d4-fef1e60245c0
section: purpose
title: Purpose & Intent
comp_id: idearium.spec-engine
seam_id: idearium.spec-engine:v1:chunk:d6b942ea:purpose
contract_id: spec-contract:d6b942ea:purpose:f82321c7
agent: ollama
model: unknown
status: complete
completed_at: 2026-07-11T01:10:28.641Z
---

<!-- imported block: intent -->

# BLOCK 2 — INTENT
  # ════════════════════════════════════════════════════════════════
  intent:
    purpose: >
      causal-nexus is a real-time causal event engine for Node.js and browser environments.
      It provides a bounded ring buffer with a built-in gate system, explicit causal graph,
      delta analytics, CQL query, persistence (WAL + archive), and AI-powered self-modification
      (forge). Every event carries a declared causal edge type — causality is declared at
      ingestion, never inferred post-hoc. The engine is designed to be embedded in any project
      as a dependency with zero runtime dependencies of its own.

    problem_statement: >
      Most event systems lose causal context: they emit events but cannot answer "what caused
      this?" or "what will break if this changes?". Replay is undirected. Snapshots are opaque
      blobs. Memory is unbounded. Gate logic is scattered and untestable. causal-nexus solves
      all of these by making causality first-class, bounding memory via ring eviction, and
      making gate logic declarative, composable, and AI-writable.

    stakeholders:
      - name: library-consumer
        role: >
          Imports causal-nexus as a dependency. Uses kernel, adapter, query, persist, forge.
          Expects zero runtime deps, ES module API, Node >= 18.
      - name: guardian-operator
        role: >
          Runs Guardian browser extension (v5.0.0). Injects DOM, AI-tab, and callto events
          into a host application via the bridge bus. Expects reliable calltoMap linkage and
          session boundary detection.
      - name: ai-agent
        role: >
          Uses forge module to autonomously modify causal-nexus modules.
          Expects stable law registry and atomic loader output.
      - name: spec-pipeline
        role: >
          Reads and patches this spec via masteravos-pipeline. Expects machine-parseable
          schema, causal_map, and enforcement block with BoundaryIndex coverage.

    non_goals:
      - causal-nexus is not a message broker. It does not route events between services.
      - causal-nexus is not a database. Persistence is a WAL + archive, not ACID.
      - causal-nexus is not an AI model. forge dispatches to Anthropic API — it does not train.
      - causal-nexus does not replace version control. Blueprints supplement git, not replace it.
      - causal-nexus does not manage UI state. The ring is the source of truth, not a component store.
      - causal-nexus does not enforce application-level business logic. Gates are structural only.
      - nexus-topo (SISO/SNR) is a separate package. causal-nexus has no dependency on it.

    invariants:
      - id: INV-I1
        statement: >
          event.id is UUID v4 — never deterministic, never reused.
        criticality: fatal
        enforced_by: [GATE-002]
        detection: enforcement.BoundaryIndex monitors every ingested event. Throws InvariantViolationError.
        consequence: Dedup, causal graph, and snapshot replay all break. Events become indistinguishable.

      - id: INV-I2
        statement: >
          contentHash is orthogonal to eventId — identical payloads produce the same hash
          but always different ids. contentHash must never be used as a dedup key for id assignment.
        criticality: fatal
        enforced_by: [GATE-002]
        detection: enforcement.BoundaryIndex. Throws InvariantViolationError.
        consequence: Identical payloads become indistinguishable. Dedup incorrectly suppresses real events.

      - id: INV-C1
        statement: >
          Every causal edge has an explicitly declared edgeType at ingestion time.
          edgeType is never inferred post-hoc from event shape.
        criticality: fatal
        enforced_by: [GATE-003]
        detection: enforcement.BoundaryIndex checks edgeType on every edge creation.
        consequence: Causal traversal (traceToRoot, descendants) becomes unreliable.

      - id: INV-C2
        statement: >
          macro:detected is never a kernel event — projection-only. No component may call
          kernel.ingest('macro:detected', ...).
        criticality: fatal
        enforced_by: [GATE-003]
        detection: BoundaryIndex monitors ingest calls. Throws immediately on C-2 violation.
        consequence: Macro projection corrupts event ring with synthetic events.

      - id: INV-C3
        statement: >
          traceToRoot traverses only causal/* edges. Observational edges are never traversed
          in causal path queries.
        criticality: fatal
        enforced_by: [GATE-003]
        detection: causality.isCausalEdge() guards every traversal step.
        consequence: Causal chains include spurious observational hops. Root cause analysis breaks.

      - id: INV-C4
        statement: Gates execute before listeners. Listener callbacks never fire before gate phase completes.
        criticality: fatal
        enforced_by: [GATE-002]
        detection: Kernel pipeline order is fixed. BoundaryIndex validates pipeline order on every ingest.
        consequence: Listeners observe events before gate-generated consequences exist. Race conditions.

      - id: INV-A2
        statement: >
          Gates return GateOutput[] — they never call kernel.ingest() directly.
          Gate output is collected atomically and ingested after the gate phase.
        criticality: fatal
        enforced_by: [GATE-002]
        detection: Kernel wraps gate execution. GATE_DEPTH_MAX=20 guards recursive gate chains.
        consequence: Recursive ingest inside gate phase causes infinite loops or ordering violations.

      - id: INV-VM1
        statement: >
          All .nex artifacts (SNAP, BP, CLIP) must pass version-gate validation before
          parsing, migration, or runtime hydration.
        criticality: fatal
        enforced_by: [GATE-007]
        detection: version-gate.validate() throws GateValidationError on mismatch.
        consequence: Stale or corrupt artifacts hydrate silently. Ring state is corrupted.

      - id: INV-L2
        statement: >
          UpgradeLedger and IdeaLedger are structurally separate. Mixing is a hard throw.
        criticality: fatal
        enforced_by: [GATE-008]
        detection: LedgerError thrown on any mixing attempt. validateSeparation() enforces.
        consequence: Speculative ideas contaminate the authoritative truth ledger.

      - id: INV-L4
        statement: >
          An idea becomes an upgrade only through explicit validation via promoteIdea().
          No bypass path exists.
        criticality: fatal
        enforced_by: [GATE-008]
        detection: promoteIdea() validates entry type. Throws LedgerError on invalid type.
        consequence: Unvalidated ideas enter the authoritative record. Truth ledger is contaminated.

      - id: INV-H1
        statement: >
          The causal edge graph is bounded. pruneEdgesFor() is called on every ring eviction.
        criticality: high
        enforced_by: [GATE-004]
        detection: BoundaryIndex monitors edge count vs ring capacity.
        consequence: Memory grows unbounded. Process OOM on long-running sessions.

      - id: INV-H6
        statement: >
          seenMap (dedup LRU) is bounded at MAX_SEEN_MAP=10,000 entries under replay flood.
        criticality: high
        enforced_by: [GATE-004]
        detection: BoundaryIndex monitors seenMap.size on every replay.
        consequence: Replay flood causes unbounded seenMap growth and eventual OOM.

    tradeoffs:
      - id: TRDE-001
        accepted: >
          Ring eviction loses event history. Events older than ringCap are gone from the ring.
        rationale: >
          Unbounded ring growth causes OOM on long-running processes. WAL + archive handles
          durability at the cost of query latency for cold data.
        revisit_condition: >
          Revisit when cold archive query latency exceeds 500ms for date-range queries,
          or when ring capacity requirements exceed 10M events.
        accepted_at: 2025-06-01T00:00:00Z
        accepted_by: james-brooks

      - id: TRDE-002
        accepted: >
          query accesses kernel._typeIndex directly for the O(1) fast path.
          Deliberate tight coupling to a _ prefixed internal field.
        rationale: >
          The typeIndex fast path reduces query latency from O(n) to O(1) for type-equality
          root conditions. Without this, every type query is a full ring scan.
        revisit_condition: >
          Revisit when a public query API stable enough to replace _typeIndex is added,
          or when _typeIndex shape changes break the query module.
        accepted_at: 2025-08-01T00:00:00Z
        accepted_by: james-brooks

      - id: TRDE-003
        accepted: >
          persist uses dynamic import of compress at flush/recover time to avoid a circular
          dependency (compress imports kernel; persist importing compress at load time cycles).
        rationale: >
          Dynamic import localizes the coupling to the call site and is cheaper than
          restructuring the module graph.
        revisit_condition: >
          Revisit when compress is decoupled from kernel (kernel passed as argument),
          making the circular dependency moot.
        accepted_at: 2025-09-01T00:00:00Z
        accepted_by: james-brooks

      - id: TRDE-004
        accepted: >
          forge requires Anthropic API access. No local-first fallback for AI self-modification.
        rationale: >
          Local model inference for module-level code rewriting at required quality is not
          available without significant infrastructure. forge is operator-invoked, not hot-path.
        revisit_condition: >
          Revisit when local code-generation models reach quality parity with claude-sonnet-4
          for module-level JS rewriting tasks.
        accepted_at: 2025-10-01T00:00:00Z
        accepted_by: james-brooks

    success_conditions:
      - Ring buffer O(1) ingest sustained at 100k events/s on Node 18 with ringCap=5_000_000.
      - traceToRoot returns correct root for chains of depth >= 50 without traversing observational edges.
      - Gate system fires before all listeners on every ingest (C-4 verified by cross-domain test suite).
      - 195 tests pass (node test/runner.js). Cross-domain invariant suite green on every release.
      - forge produces valid, loadable ES module patches for >= 80% of well-formed patch descriptions.
      - persist.recoverStore() replays WAL with zero data loss for clean shutdowns.
      - version-gate rejects major-version mismatched .nex artifacts with GateValidationError.
      - BoundaryIndex reports 29/29 invariants passing on a fresh kernel with no violations.

    failure_conditions:
      - InvariantViolationError thrown during normal operation (any invariant group).
      - Ring eviction does not call pruneEdgesFor — edge graph grows unbounded (H-1 violated).
      - query module accesses stale typeIndex after kernel.reset() without defensive copy (H-3 violated).
      - forge produces syntactically invalid ES module output that fails loader evaluation.
      - recoverStore() returns ok:false with errors for a WAL produced by a clean shutdown.
      - version-gate allows a major-version mismatched artifact to hydrate silently (VM-1 violated).
      - promoteIdea() succeeds without a valid entry type — unvalidated idea enters UpgradeLedger.

    risk_assumptions:
      - id: RISK-001
        assumption: Anthropic API remains available and stable for forge operations.
        confidence: high
        if_wrong: >
          forge becomes unavailable. AI self-modification halts. Manual patching required.
          No runtime impact — forge is not in the hot path.
        validation_method: >
          forge wraps all API calls in try/catch. On failure, returns { ok: false, error }.

      - id: RISK-002
        assumption: ringCap=5_000_000 is sufficient for production use without excessive eviction.
        confidence: medium
        if_wrong: >
          High eviction rates cause H-1 pressure. Cold archive queries increase in frequency.
        validation_method: >
          Monitor system:ring:evicted event rate. Alert if > 1% of ingest rate.

      - id: RISK-003
        assumption: Guardian extension (v5.0.0) bridge protocol is stable across Firefox updates.
        confidence: medium
        if_wrong: Bridge bus events stop arriving. Session boundary detection fails.
        validation_method: >
          Guardian handshake.js tests connection on every popup open. Adapter logs warning
          if no events received within 30s of session start.

  # ════════════════════════════════════════════════════════════════