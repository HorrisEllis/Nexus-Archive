'use strict';
/**
 * loom/server.js — Sovereign LOOM system
 * comp_id: nexus.loom.server
 * UUID: nexus-loom-server-v1-0000-2026-0702-jamesbrooks-001
 * Port: 3752
 *
 * §GAP CLOSED 2026-07-02: LOOM (component/hook/wire/seam registry +
 * contracts) has existed since phase 121 as a pure library — LoomDriver
 * and LoomContracts, required in-process by whatever needed the
 * registry. loom/schema/index.js's own header comment names this
 * explicitly: "this is CLI/API's future entry point (Phase 132/133)" —
 * the API layer was planned, never built. Every other real system in
 * NEXUS follows nexus-system-foundation.spec's L0-L5 shape and has a
 * process, a port, and a handshake with the orchestrator. LOOM had L0
 * (schema/registry) and an L2-adjacent CLI, nothing else. This file is
 * L3 (API) + L4 (handshake) — the same boot pattern copilot/server.js
 * and eravos/server.js already use, not a new pattern invented here.
 *
 * Read-only surface wraps LoomDriver.registry directly (has/get/all/
 * graph — already disk-first, already re-reads before every read per
 * the phase-157 staleness fix). Write surface wraps declare() and the
 * three LoomContracts lifecycle calls. Nothing here reimplements gate/
 * axiom logic — this is transport only, same as every other system's
 * server.js is transport in front of its own lib/.
 */

const http = require('http');
const fs   = require('fs');
const { LoomDriver } = require('./schema/index');
const { LoomContracts } = require('./contracts/index');
// §BUGFIX 2026-07-04: this module was built earlier this session
// specifically to give LOOM a durable write path into cortex — and then
// never actually connected to anything. Wiring it in now: every real
// registry mutation below also records through here.
const cortexSync = require('./schema/cortex-sync');
// §GAP CLOSED 2026-07-05: loom/ingest/index.js (LoomIngest.ingestZip) was
// built in phase 144 — sha256 identity, real unzip listing, parent-diff
// lineage, all working and tested — and then never wired to an actual
// endpoint. Same shape as cortexSync's own history two lines above:
// built, correct, disconnected. Wiring it in now via /api/ingest.
const { LoomIngest } = require('./ingest/index');
// §GAP CLOSED 2026-07-05: same pattern a third time — scaffoldSystem
// (loom/templates/system-scaffold.js, phase 145) is a real, tested
// operations-list → CLI+API+contract projector, never wired to an
// endpoint either. /api/scaffold below is what a UI checkbox form
// actually calls.
const { scaffoldSystem } = require('./templates/system-scaffold');
const path = require('path');

const SYSTEM_ID = 'loom';
const PORT      = parseInt(process.env.LOOM_PORT || '3752');
const OR_URL    = process.env.ORCH_URL || 'http://127.0.0.1:9000';
// §2026-07-04: sourced from the central registry from day one, unlike the
// other systems this session found drifted — loom is new enough to just
// do it right rather than fix it twice.
const VERSION   = require('../lib/version').services.loom;

// ── Scaffold templates — real operations, system-scaffold's own shape ──────
// Not placeholders: each of these is a valid `operations` array on its
// own — scaffoldSystem() has been run against "Basic CRUD" directly
// while wiring this in, same way ingest was proven against a real zip
// before calling it done.
const SCAFFOLD_TEMPLATES = [
  {
    id: 'crud-basic', label: 'Basic CRUD',
    description: 'list/get/create/update/delete over one resource',
    operations: [
      { id: 'list',   verb: 'list',   method: 'GET',    apiPath: '/items',      params: [], description: 'list all items' },
      { id: 'get',    verb: 'get',    method: 'GET',    apiPath: '/items/:id',  params: ['id'], description: 'get one item' },
      { id: 'create', verb: 'create', method: 'POST',   apiPath: '/items',      params: ['data'], description: 'create an item' },
      { id: 'update', verb: 'update', method: 'PATCH',  apiPath: '/items/:id',  params: ['id', 'data'], description: 'update an item' },
      { id: 'delete', verb: 'delete', method: 'DELETE', apiPath: '/items/:id',  params: ['id'], description: 'delete an item' },
    ],
  },
  {
    id: 'read-only-registry', label: 'Read-only registry',
    description: 'query-only surface over a data set — no mutation verbs at all',
    operations: [
      { id: 'list',   verb: 'list',   method: 'GET', apiPath: '/records',       params: [], description: 'list all records' },
      { id: 'get',    verb: 'get',    method: 'GET', apiPath: '/records/:id',   params: ['id'], description: 'get one record' },
      { id: 'search', verb: 'search', method: 'GET', apiPath: '/records/search', params: ['q'], description: 'full-text search' },
    ],
  },
  {
    id: 'job-queue', label: 'Job queue',
    description: 'submit/status/cancel — same shape ollama/copilot/guardian already use for dispatch',
    operations: [
      { id: 'submit', verb: 'submit', method: 'POST', apiPath: '/jobs',          params: ['payload'], description: 'submit a job' },
      { id: 'status', verb: 'status', method: 'GET',  apiPath: '/jobs/:id',      params: ['id'], description: 'check job status' },
      { id: 'cancel', verb: 'cancel', method: 'POST', apiPath: '/jobs/:id/cancel', params: ['id'], description: 'cancel a queued job' },
    ],
  },
];

const driver    = new LoomDriver();
const ingest    = new LoomIngest();
const contracts = new LoomContracts();
const _sseClients = new Set();
function _broadcast(type, payload) {
  const line = `data: ${JSON.stringify({ type, ...payload, ts: Date.now() })}\n\n`;
  for (const res of _sseClients) { try { res.write(line); } catch (_) { _sseClients.delete(res); } }
}

function json(res, code, body) {
  const s = JSON.stringify(body);
  res.writeHead(code, { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(s) });
  res.end(s);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let data = '';
    req.on('data', c => { data += c; if (data.length > 2_000_000) req.destroy(); });
    req.on('end', () => { try { resolve(data ? JSON.parse(data) : {}); } catch (e) { reject(e); } });
    req.on('error', reject);
  });
}

// §ADDED 2026-07-05: readBody above JSON.parses its input, which corrupts
// binary data — no use for actual zip bytes. A typed file path was never
// going to work as the real ingest path anyway: browsers do not expose
// real filesystem paths for dropped/selected files (Windows included —
// drag-and-drop from Explorer hands back a File object with bytes, never
// C:\Users\...\thing.zip). This reads the raw body as a Buffer instead,
// capped generously since real build zips run large (loom/ingest/index.js's
// own header cites a 178MB/10,991-entry example).
function readRawBody(req, maxBytes = 500 * 1024 * 1024) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on('data', c => {
      size += c.length;
      if (size > maxBytes) { req.destroy(); reject(new Error(`upload exceeds ${maxBytes} byte limit`)); return; }
      chunks.push(c);
    });
    req.on('end', () => resolve(Buffer.concat(chunks)));
    req.on('error', reject);
  });
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://127.0.0.1:${PORT}`);
  const p = url.pathname;
  const method = req.method;

  try {
    if (method === 'GET' && (p === '/' || p === '/ui')) {
      const html = fs.readFileSync(path.join(__dirname, 'ui', 'index.html'), 'utf8');
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
      res.end(html);
      return;
    }

    if (method === 'GET' && p === '/events') {
      res.writeHead(200, {
        'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache',
        'Connection': 'keep-alive', 'Access-Control-Allow-Origin': '*',
      });
      res.write(`data: ${JSON.stringify({ type: 'loom.connected', ts: Date.now() })}\n\n`);
      _sseClients.add(res);
      req.on('close', () => _sseClients.delete(res));
      return;
    }

    if (method === 'GET' && p === '/health') {
      return json(res, 200, { ok: true, systemId: SYSTEM_ID, version: VERSION });
    }

    // Same shape as every other sovereign system's /contract (phase 137
    // audit — cortex/bridge/architect all needed this added this session).
    if (method === 'GET' && p === '/contract') {
      return json(res, 200, {
        id: 'loom-v1', systemId: SYSTEM_ID, version: VERSION,
        routes: ['GET /health', 'GET /contract', 'GET /api/registry/:kind',
          'GET /api/registry/:kind/:id', 'POST /api/registry/:kind', 'GET /api/graph', 'GET /api/context-graph', 'GET /api/impact/:id',
          'POST /api/contracts', 'POST /api/contracts/:id/handoff', 'POST /api/contracts/:id/close',
          'POST /api/ingest', 'POST /api/ingest-upload', 'GET /api/revisions', 'GET /api/revisions/:id',
          'GET /api/templates', 'POST /api/scaffold'],
      });
    }

    // ── Registry (LoomDriver) ────────────────────────────────────────────
    if (method === 'GET' && p.startsWith('/api/registry/')) {
      const parts = p.split('/').filter(Boolean); // ['api','registry',kind,id?]
      const kind = parts[2];
      const id = parts[3];
      if (id) {
        const rec = driver.registry.get(kind, decodeURIComponent(id));
        return rec ? json(res, 200, { ok: true, record: rec }) : json(res, 404, { ok: false, error: 'not found' });
      }
      return json(res, 200, { ok: true, kind, records: driver.registry.all(kind) });
    }

    if (method === 'POST' && p.startsWith('/api/registry/')) {
      const kind = p.split('/')[3];
      const payload = await readBody(req);
      const result = driver.declare(kind, payload);
      if (result.ok !== false) {
        cortexSync.record('add', kind, payload);
        _broadcast('loom.registry.declared', { kind, id: payload?.id });
      }
      return json(res, result.ok === false ? 409 : 200, result);
    }

    if (method === 'GET' && p === '/api/graph') {
      return json(res, 200, { ok: true, graph: driver.registry.graph() });
    }
    // §part_2 2026-07-10 — the semantic query layer. context-graph resolves
    // wires to component-level relations with intent; impact answers "if this
    // breaks, who fails downstream and what intents break". This is what makes
    // the registry a queryable nervous system, not just a filing cabinet.
    if (method === 'GET' && p === '/api/context-graph') {
      return json(res, 200, { ok: true, contextGraph: driver.registry.contextGraph() });
    }
    if (method === 'GET' && p.startsWith('/api/impact/')) {
      const componentId = decodeURIComponent(p.slice('/api/impact/'.length));
      if (!componentId) return json(res, 400, { ok: false, error: 'component id required' });
      return json(res, 200, { ok: true, impact: driver.registry.impactOf(componentId) });
    }

    // ── Ingest (LoomIngest) — old iteration zips ─────────────────────────
    // POST /api/ingest {zipPath, label} — matches LoomIngest's own contract:
    // "the function a drop handler will call once UI exists." zipPath must
    // be a path already on this machine (an uploaded file's saved path,
    // or a CLI-supplied path) — this endpoint does not accept raw upload
    // bytes; that's a separate, later concern (multipart handling), not
    // implied by wiring the existing ingest call in.
    if (method === 'POST' && p === '/api/ingest') {
      const body = await readBody(req);
      if (!body?.zipPath) return json(res, 400, { ok: false, error: 'zipPath is required' });
      try {
        const record = ingest.ingestZip(body.zipPath, { label: body.label });
        cortexSync.record('ingest', 'revision', record);
        _broadcast('loom.revision.ingested', { id: record.id, label: record.label, alreadyIngested: !!record.alreadyIngested });
        return json(res, 200, { ok: true, record: { ...record, _rawEntries: undefined } });
      } catch (e) { return json(res, 400, { ok: false, error: e.message }); }
    }

    if (method === 'GET' && p === '/api/revisions') {
      // §fix: RevisionRegistry.all() returns {id: record, ...}, not an
      // array — Object.values(), not .map() directly on the result.
      const revisions = Object.values(ingest.revisions.all()).map(r => ({ ...r, _rawEntries: undefined }));
      return json(res, 200, { ok: true, revisions });
    }

    if (method === 'GET' && /^\/api\/revisions\/[^/]+$/.test(p)) {
      const id = decodeURIComponent(p.split('/')[3]);
      const record = ingest.revisions.get(id);
      if (!record) return json(res, 404, { ok: false, error: 'not found' });
      return json(res, 200, { ok: true, record: { ...record, _rawEntries: undefined }, summary: ingest.summary(id) });
    }

    // ── Scaffold (system-scaffold.js) — templates + custom operations ────────
    // GET /api/templates — named, pre-built operation sets a checkbox UI
    // picks from. Each entry is real operations, in system-scaffold's own
    // {id, verb, method, apiPath, params, description} shape — checking a
    // template box and unchecking one operation from it is a normal edit,
    // not a special case, because both paths produce the same operations
    // array scaffoldSystem() already accepts.
    if (method === 'GET' && p === '/api/templates') {
      return json(res, 200, { ok: true, templates: SCAFFOLD_TEMPLATES });
    }

    // POST /api/ingest-upload — real file upload, the actual drag-and-drop
    // path. Filename comes via X-Filename header (URL-encoded) since this
    // is a raw binary body, not multipart/form-data — no new dependency
    // added for it, same zero-dependency stance loom/ingest/index.js's own
    // header states. Saves to disk, then runs the exact same ingestZip()
    // the path-based /api/ingest above uses — one ingest engine, two ways
    // to hand it a file.
    if (method === 'POST' && p === '/api/ingest-upload') {
      const rawName = req.headers['x-filename'];
      if (!rawName) return json(res, 400, { ok: false, error: 'X-Filename header is required' });
      const filename = decodeURIComponent(rawName).replace(/[^a-zA-Z0-9._-]/g, '_');
      let buf;
      try { buf = await readRawBody(req); }
      catch (e) { return json(res, 413, { ok: false, error: e.message }); }
      if (!buf.length) return json(res, 400, { ok: false, error: 'empty upload' });

      const uploadDir = path.join(__dirname, '..', 'data', 'loom', 'uploads');
      fs.mkdirSync(uploadDir, { recursive: true });
      const savedPath = path.join(uploadDir, `${Date.now()}__${filename}`);
      fs.writeFileSync(savedPath, buf);

      try {
        const record = ingest.ingestZip(savedPath, { label: filename });
        cortexSync.record('ingest', 'revision', record);
        _broadcast('loom.revision.ingested', { id: record.id, label: record.label, alreadyIngested: !!record.alreadyIngested });
        return json(res, 200, { ok: true, record: { ...record, _rawEntries: undefined } });
      } catch (e) { return json(res, 400, { ok: false, error: e.message }); }
    }

    if (method === 'POST' && p === '/api/scaffold') {
      const body = await readBody(req);
      const { name, port, purpose, operations } = body || {};
      if (!name || !port || !operations) {
        return json(res, 400, { ok: false, error: 'name, port, and operations are required' });
      }
      try {
        const result = scaffoldSystem(name, {
          port, purpose, operations,
          outDir: path.join(__dirname, '..', 'data', 'loom', 'scaffolded'),
          // no dataDir override — same loom/data/registry.json the live
          // `driver` above already reads, so a scaffolded component shows
          // up in /api/registry and /api/graph immediately, not in a
          // second, disconnected registry file.
        });
        cortexSync.record('scaffold', 'component', { name, port, operations: operations.map(o => o.id) });
        _broadcast('loom.system.scaffolded', { name, port, fileCount: result.written.length });
        return json(res, 200, { ok: true, ...result });
      } catch (e) { return json(res, 400, { ok: false, error: e.message }); }
    }

    // ── Contracts (LoomContracts) ────────────────────────────────────────
    if (method === 'POST' && p === '/api/contracts') {
      const body = await readBody(req);
      try {
        const contract = contracts.openContract(body);
        cortexSync.record('contract-open', 'contract', contract);
        _broadcast('loom.contract.opened', { id: contract?.id, componentId: body?.componentId });
        return json(res, 200, { ok: true, contract });
      } catch (e) { return json(res, 400, { ok: false, error: e.message }); }
    }

    if (method === 'POST' && /^\/api\/contracts\/[^/]+\/handoff$/.test(p)) {
      const id = p.split('/')[3];
      const body = await readBody(req);
      try {
        const contract = contracts.recordHandoff(id, body);
        _broadcast('loom.contract.handoff', { id });
        return json(res, 200, { ok: true, contract });
      } catch (e) { return json(res, 400, { ok: false, error: e.message }); }
    }

    if (method === 'POST' && /^\/api\/contracts\/[^/]+\/close$/.test(p)) {
      const id = p.split('/')[3];
      const body = await readBody(req);
      try {
        const contract = contracts.closeContract(id, body);
        cortexSync.record('contract-close', 'contract', contract);
        _broadcast('loom.contract.closed', { id, status: contract?.status });
        return json(res, 200, { ok: true, contract });
      } catch (e) { return json(res, 400, { ok: false, error: e.message }); }
    }

    json(res, 404, { ok: false, error: 'not found' });
  } catch (e) {
    json(res, 500, { ok: false, error: e.message });
  }
});

// ── Register with orchestrator — same pattern every sovereign system uses ──
function register() {
  const body = JSON.stringify({
    systemId: SYSTEM_ID, port: PORT, version: VERSION, status: 'online',
    meta: { label: 'LOOM', color: '#33bb88' }, components: [],
  });
  const u = new URL(`${OR_URL}/api/register`);
  const r = http.request({ hostname: u.hostname, port: u.port || 9000, path: u.pathname,
    method: 'POST', headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body) },
    timeout: 4000 }, () => {
    console.log('[loom] registered');
    try {
      const { startHeartbeat } = require('../nexus-connect');
      startHeartbeat(SYSTEM_ID, PORT);
    } catch (_) { /* nexus-connect optional — never crash the server over a heartbeat */ }
  });
  r.on('error', () => setTimeout(register, 5000));
  r.write(body); r.end();
}

server.listen(PORT, () => {
  console.log(`[loom] :${PORT} — v${VERSION} — component/hook/wire/seam registry + contracts`);
  setTimeout(register, 1000);
});

module.exports = { server, driver, contracts };
