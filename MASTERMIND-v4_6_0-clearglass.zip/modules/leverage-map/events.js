// ═══════════════════════════════════════════════════════════════════
// LEVERAGE MAP — events.js
// v1.0.0
//
// This module's public bus contract. Read this file to know everything
// another module is allowed to assume about Leverage Map, per the
// module contract in NEXUS-SPEC.md Part 2.4.
//
//   emits:  leverage.node.scored     { id, score, tension, weight, slope }
//           leverage.node.kind_set   { id, kind }
//
//   listens: none yet — v1 is self-contained. When the Becoming Engine
//   (NEXUS-SPEC.md Part 3) is built, it's expected to LISTEN for these
//   two events to feed Growth Slope, rather than Leverage Map reaching
//   into Becoming's state — that direction of dependency (Becoming
//   listens to Leverage Map) is the correct one per the module
//   contract's "no module imports another module directly" rule.
// ═══════════════════════════════════════════════════════════════════

'use strict';

(function () {
  if (typeof MM_WARP === 'undefined') {
    console.warn('[leverage-map] MM_WARP not loaded — leverage.* events will not be routed through the bus');
    return;
  }

  // Real Gates for both event types, so they're accounted in
  // MM_WARP.log.entries() like everything else on the spine, instead of
  // landing in stream.pending with nothing claiming them.
  MM_WARP.stream.register(new WARP.Gate('leverage.node.scored', {
    transform() { return null; }, // terminal — logged, no further routing yet
  }));
  MM_WARP.stream.register(new WARP.Gate('leverage.node.kind_set', {
    transform() { return null; },
  }));
})();
