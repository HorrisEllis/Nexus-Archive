// ═══════════════════════════════════════════════════════════════════
// CLEARGLASS TRANSPORT — foundation/ai/clearglass-transport.js
// v1.0.0
//
// Built against the real clear-glass-lite-6.zip source, specifically
// interaction-contract.json + guardian-lite/server.js + userscripts.js.
// Not guessed — every endpoint and shape here matches that contract.
//
// The important thing this file is NOT: ClearGlass Lite has no endpoint
// that takes a prompt and returns a completion. There's no public API
// for Claude/ChatGPT/Gemini a third party can call directly — that's
// the whole reason ClearGlass exists (a real browser window + a real
// logged-in session + userscript DOM automation). So this transport:
//
//   1. POSTs the request to guardian-lite's real /ingest endpoint,
//      table 'mastermind-requests' — completely generic, guardian-lite
//      has no fixed schema beyond "a table name and a JSON object."
//   2. Polls guardian-lite's real /query endpoint for a matching row in
//      'mastermind-responses', until the bridge userscript (running
//      inside the actual Claude tab ClearGlass opened) posts one.
//
// The bridge userscript itself lives in
// integrations/clearglass/mastermind-bridge.user.js — it has to be
// manually copied into ClearGlass Lite's userscripts folder, since
// Mastermind has no way to write files into a separate app's data
// directory. See that file's own header for what it does and the one
// genuinely uncertain part (Claude's DOM selectors).
// ═══════════════════════════════════════════════════════════════════

'use strict';

const CLEARGLASS_BASE = 'http://127.0.0.1:7823'; // guardian-lite default port, per interaction-contract.json

async function clearglassHealthCheck() {
  try {
    const res = await fetch(CLEARGLASS_BASE + '/health', { signal: AbortSignal.timeout(2000) });
    if (!res.ok) return false;
    const data = await res.json();
    return data.ok === true;
  } catch (e) {
    return false; // guardian-lite not running, or ClearGlass Lite isn't open
  }
}

async function clearglassCall(systemPrompt, userMessage, opts = {}) {
  const requestId = 'mm-' + Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
  // AI replies here are DOM-scraped from a real chat UI, not a direct API
  // response — that's meaningfully slower than a normal fetch, and how
  // slow varies a lot by prompt. 90s default, callers can override.
  const timeoutMs = opts.timeoutMs || 90000;
  const pollMs = opts.pollMs || 1500;

  const alive = await clearglassHealthCheck();
  if (!alive) {
    throw new Error('ClearGlass Lite not reachable at 127.0.0.1:7823 — is it running?');
  }

  const ingestRes = await fetch(CLEARGLASS_BASE + '/ingest', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      table: 'mastermind-requests',
      requestId,
      systemPrompt: systemPrompt || '',
      userMessage: userMessage || '',
      ts: Date.now(),
    }),
  });
  if (!ingestRes.ok) {
    throw new Error('guardian-lite refused the request (HTTP ' + ingestRes.status + ')');
  }

  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    await new Promise(r => setTimeout(r, pollMs));
    try {
      const q = await fetch(`${CLEARGLASS_BASE}/query?table=mastermind-responses&requestId=${encodeURIComponent(requestId)}&limit=1`);
      if (!q.ok) continue;
      const data = await q.json();
      if (data.rows && data.rows.length) {
        return data.rows[0].text || '';
      }
    } catch (e) {
      // transient — keep polling until the deadline
    }
  }

  throw new Error('ClearGlass timed out waiting for a reply — is the Mastermind bridge userscript active in a Claude tab? (integrations/clearglass/mastermind-bridge.user.js, installed in ClearGlass Lite\u2019s userscripts folder)');
}

window.clearglassHealthCheck = clearglassHealthCheck;
window.clearglassCall = clearglassCall;
