// ==UserScript==
// @name        Mastermind Bridge
// @match       https://claude.ai/*
// @enabled     true
// ==/UserScript==

// ═══════════════════════════════════════════════════════════════════
// Mastermind Bridge — runs inside the real, logged-in Claude tab that
// ClearGlass Lite opens. Polls guardian-lite (127.0.0.1:7823, ClearGlass
// Lite's real local capture API — see interaction-contract.json in the
// clear-glass-lite source) for prompt requests Mastermind has queued,
// types them into Claude's actual chat UI, waits for the reply, and
// posts the scraped text back.
//
// INSTALL: copy this file into ClearGlass Lite's userscripts folder
// (Options → "Open scripts folder" in the ClearGlass Lite hub window,
// or find it directly — see clear-glass-lite's README for the exact
// path per OS). It's picked up automatically, per userscripts.js's real
// load-on-page-navigation behavior — no restart needed.
//
// HONEST CAVEAT — read this before assuming it "just works":
// findComposer() and waitForReply() guess at Claude's current DOM
// structure. I don't have live access to claude.ai to verify the exact
// selectors against what's actually shipped today, so these are
// reasonable, defensively-written guesses (a contenteditable
// ProseMirror-based composer, a "Stop generating" button that
// disappears when a reply finishes) — not confirmed. If prompts aren't
// submitting or replies aren't being captured, THIS is the first place
// to look: open Claude in a normal browser tab, inspect the actual
// input box and reply container, and update findComposer()/
// findSendButton()/waitForReply() to match what's really there.
// A broken selector fails loudly to the console (per-request, not
// per-page — see the catch block in pollForRequests) rather than
// silently, so it should be diagnosable from DevTools rather than a
// mystery.
// ═══════════════════════════════════════════════════════════════════

(function () {
  const GUARDIAN = 'http://127.0.0.1:7823';
  const POLL_MS = 2000;
  const seen = new Set(); // requestIds already handled this page session — avoids double-submitting on repeat polls

  function GM_fetch_json(url) {
    return new Promise((resolve) => {
      GM_xmlhttpRequest({
        method: 'GET', url,
        onload: (r) => { try { resolve(JSON.parse(r.responseText)); } catch (e) { resolve(null); } },
        onerror: () => resolve(null),
        ontimeout: () => resolve(null),
      });
    });
  }

  function GM_post_json(url, body) {
    return new Promise((resolve) => {
      GM_xmlhttpRequest({
        method: 'POST', url,
        headers: { 'Content-Type': 'application/json' },
        data: JSON.stringify(body),
        onload: () => resolve(true),
        onerror: () => resolve(false),
      });
    });
  }

  // ── The uncertain part — see header caveat ─────────────────────
  function findComposer() {
    return document.querySelector('div[contenteditable="true"][class*="ProseMirror"]')
        || document.querySelector('div[contenteditable="true"]')
        || document.querySelector('textarea');
  }

  function findSendButton() {
    return document.querySelector('button[aria-label*="Send" i]')
        || document.querySelector('button[type="submit"]');
  }

  async function submitPrompt(text) {
    const composer = findComposer();
    if (!composer) throw new Error("Could not find Claude's input box — DOM selector likely needs updating, see this script's header");
    composer.focus();
    document.execCommand('insertText', false, text);
    composer.dispatchEvent(new InputEvent('input', { bubbles: true }));
    await new Promise(r => setTimeout(r, 300));
    const sendBtn = findSendButton();
    if (sendBtn) sendBtn.click();
    else composer.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', bubbles: true }));
  }

  async function waitForReply(timeoutMs = 60000) {
    const deadline = Date.now() + timeoutMs;
    while (Date.now() < deadline) {
      const stillGenerating = document.querySelector('button[aria-label*="Stop" i]');
      if (!stillGenerating) {
        const blocks = document.querySelectorAll('[data-testid="conversation-turn"], .font-claude-message');
        if (blocks.length) {
          const last = blocks[blocks.length - 1];
          const text = last.innerText?.trim();
          if (text) return text;
        }
      }
      await new Promise(r => setTimeout(r, 800));
    }
    throw new Error("Timed out waiting for Claude's reply");
  }
  // ── End uncertain part ──────────────────────────────────────────

  async function pollForRequests() {
    const res = await GM_fetch_json(`${GUARDIAN}/query?table=mastermind-requests&limit=5`);
    if (!res || !res.rows) return; // guardian-lite not reachable, or nothing queued — normal, just wait for next poll

    for (const row of res.rows) {
      if (seen.has(row.requestId)) continue;
      seen.add(row.requestId);
      try {
        const prompt = (row.systemPrompt ? row.systemPrompt + '\n\n' : '') + row.userMessage;
        await submitPrompt(prompt);
        const reply = await waitForReply();
        await GM_post_json(`${GUARDIAN}/ingest`, {
          table: 'mastermind-responses', requestId: row.requestId, text: reply, ts: Date.now(),
        });
      } catch (e) {
        console.error('[mastermind-bridge]', row.requestId, e);
        // Post the error back too — Mastermind's poll loop times out
        // either way, but a visible error message beats total silence.
        await GM_post_json(`${GUARDIAN}/ingest`, {
          table: 'mastermind-responses', requestId: row.requestId,
          text: '[mastermind-bridge error: ' + e.message + ']', ts: Date.now(),
        });
      }
    }
  }

  setInterval(pollForRequests, POLL_MS);
  console.log('[mastermind-bridge] active — polling guardian-lite for Mastermind requests every ' + POLL_MS + 'ms');
})();
