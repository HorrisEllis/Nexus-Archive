# Mastermind × ClearGlass Lite

Real integration, built against the actual `clear-glass-lite-6.zip` source
(`interaction-contract.json`, `guardian-lite/server.js`, `userscripts.js`) —
not guessed against the ClearGlass boot log's text output like the first
attempt at this would have been.

## Why this isn't a simple API call

ClearGlass Lite has no endpoint that takes a prompt and returns a
completion. There's no public third-party API for Claude, ChatGPT, or
Gemini to call directly — that's the entire reason ClearGlass exists: a
real browser window, a real logged-in session, and userscript DOM
automation, because an actual delegated-API login flow isn't available
from these providers to build against. (Confirmed straight from
clear-glass-lite's own README — it says this plainly, this isn't an
assumption.)

So the integration is two real, independent pieces talking through
guardian-lite (ClearGlass Lite's real local capture API, `127.0.0.1:7823`):

```
Mastermind                 guardian-lite              Claude tab (ClearGlass)
    │                       (127.0.0.1:7823)                  │
    │── POST /ingest ─────────────►│                          │
    │   table: mastermind-requests │                          │
    │                               │◄── GET /query ───────────│ (bridge userscript polls)
    │                               │                          │
    │                               │                    types prompt into
    │                               │                    Claude's real UI,
    │                               │                    waits for reply
    │                               │                          │
    │                               │◄── POST /ingest ─────────│
    │                               │   table: mastermind-responses
    │◄── GET /query (polling) ─────│                          │
    │   table: mastermind-responses │                          │
```

## Setup

1. **Run ClearGlass Lite** (`npm start` in the clear-glass-lite folder —
   not `node main.js` directly, see its own README for exactly why).
2. **Log into Claude** via ClearGlass Lite's hub window — click the Claude
   button, sign in normally. This is real, persistent, per-account
   session storage; you only do this once per account.
3. **Install the bridge userscript** — copy
   `integrations/clearglass/mastermind-bridge.user.js` into ClearGlass
   Lite's userscripts folder (Options → "Open scripts folder" in the hub
   window). Picked up automatically on the Claude tab's next page load or
   navigation — no restart needed, per `userscripts.js`'s real behavior.
4. **Keep the Claude tab open.** The bridge only runs while that tab is
   loaded — it's real DOM automation inside that page, not a background
   service.
5. In Mastermind, **Options → AI → Provider → ClearGlass (userscript)**.

## What's real vs. what's a known unknown

**Real, verified against the actual source:**
- `foundation/ai/clearglass-transport.js` — every endpoint, method, and
  request/response shape matches `interaction-contract.json` exactly.
- The polling/ingest pattern, the GM_xmlhttpRequest usage in the
  userscript, the Tampermonkey metadata format — all match
  `guardian-lite/server.js` and `userscripts.js` as actually written.

**Genuinely uncertain — flagged, not hidden:**
- The userscript's `findComposer()` / `findSendButton()` / `waitForReply()`
  guess at Claude's current DOM structure. There's no way to verify these
  against the live site without actually browsing claude.ai, which wasn't
  available while building this. If prompts don't submit or replies don't
  get captured, this is the first place to look — the script's own header
  says the same thing, and errors are logged per-request to the console
  rather than failing silently.

## Not built

- ChatGPT/Gemini/Perplexity bridge userscripts — only Claude's is written,
  since that's what "only Ollama and ClearGlass" was asked for and Claude
  is ClearGlass Lite's first-listed provider. The same pattern extends to
  the others by copying `mastermind-bridge.user.js`, changing `@match`,
  and adjusting the DOM selectors for that provider's UI — real work,
  not a trivial copy-paste, since each provider's page structure differs.
- Multi-account routing — if you have multiple Claude accounts connected
  in ClearGlass Lite, this bridge runs in whichever Claude tab happens to
  have the script active. No account-targeting was built.
